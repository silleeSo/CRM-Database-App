/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
package crm_db;
import java.sql.*;
import java.util.ArrayList;

public class Person{

    private Validation validation;
    private IDGenerator idGen;
    private final String sqlIsValidPerson =  "SELECT COUNT(*) FROM person p WHERE personId = (?) AND deletedAt IS NULL;"; 
    private final String sqlInsertPerson = "INSERT INTO Person VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL);";
    private final String sqlGetAddressId = "SELECT addressId as data FROM Person p WHERE p.personId = ?;";
    private final String sqlGetContactPrefId = "SELECT contactPref as data FROM Person p WHERE p.personId = ?";
    private final String sqlUpdatePerson = "UPDATE person SET lastName = ?, firstName = ?, middleName = ?, suffix = ?, sex = ?, birthdate = ?, company = ?, position = ?, contactPref = ?, notes = ? WHERE personId = ?;";
    private final String sqlPersonsNotDel = "SELECT CONCAT(p.lastname, \", \", p.firstname) AS dropDown FROM Person p WHERE p.deletedAt IS NULL;";
    private final String sqlDeletePerson = "UPDATE Person SET deletedAt = ? WHERE personId = ?;";
    private final String sqlGetTaskablePerson = "(\tSELECT CONCAT(lastName, ', ',firstName) AS dropDown FROM Assignment a JOIN LeadAssignment la ON la.assignmentId = a.assignmentId JOIN Lead l ON la.leadNumber = l.leadNumber JOIN Person p ON p.personId = l.personId WHERE a.endDate IS NULL AND p.deletedAt IS NULL ) UNION ALL (\tSELECT CONCAT(lastName, ', ',firstName) AS dropDown FROM Assignment a JOIN CustomerAssignment ca  ON ca.assignmentId = a.assignmentId JOIN Customer c ON c.customerNumber = ca.customerNumber JOIN Person p ON p.personId = c.personId WHERE a.endDate IS NULL AND p.deletedAt IS NULL )";


    public Person(){
        validation = new Validation();
        idGen = new IDGenerator("personId", "Person");
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    public boolean isValidPerson(int personId){
        Connection conn = connectToDB();
        ResultSet expectedPersonRs;

        if(conn == null)
            return false;

        try{
            PreparedStatement validatePersonStmt = conn.prepareStatement(sqlIsValidPerson);
            validatePersonStmt.setInt(1, personId);
            expectedPersonRs = validatePersonStmt.executeQuery();   
            
            // actual checking
            if (!expectedPersonRs.isBeforeFirst()) {    
                System.out.println("No data"); 
                return false;
            }
            
            validatePersonStmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return false;
        }        
        // return false;
        
        return true;
    }


    public int addPersonToDB(  String type, String firstName, String lastName, String middleName, String suffix, 
                                String sex, String birthDate, String company, String position, String notes, 
                                int addressId, int contactPref){
        int personId;
        Connection conn = connectToDB();
        
        if(conn == null)
            return -1;

        try{
            PreparedStatement insertPersonStmt = conn.prepareStatement(sqlInsertPerson);
            personId = idGen.getNextId();

            insertPersonStmt.setInt(1, personId);
            insertPersonStmt.setString(2, lastName);
            insertPersonStmt.setString(3, firstName);
            optionalField(4, middleName, insertPersonStmt);
            optionalField(5, suffix, insertPersonStmt);
            insertPersonStmt.setString(6, sex);
            insertPersonStmt.setString(7, birthDate);
            optionalField(8, company, insertPersonStmt);
            optionalField(9, position, insertPersonStmt);
            insertPersonStmt.setInt(10, addressId);
            insertPersonStmt.setInt(11, contactPref);
            optionalField(12, notes, insertPersonStmt);
            insertPersonStmt.setString(13, type);
            insertPersonStmt.setString(14, validation.generateTimestamp());
            
            insertPersonStmt.executeUpdate();
            
            return personId;

        } catch (SQLException e) {
            System.out.println("Exception @ addPersonToDB");
            System.out.println(e.getMessage());  
            return -1;
        }    
                                    
    }

    public String updatePerson(String firstName, String lastName, String middleName, String suffix, 
                            String sex, String birthDate, String company, String position, String notes, 
                            int contactPref, int personId) {
    Connection conn = connectToDB();
    PreparedStatement pstmt;

    try {

        pstmt = conn.prepareStatement(sqlUpdatePerson);

        pstmt.setString(1, lastName);
        pstmt.setString(2, firstName);
        optionalField(3, middleName, pstmt);
        optionalField(4, suffix, pstmt);
        pstmt.setString(5, sex);
        pstmt.setString(6, birthDate);
        optionalField(7, company, pstmt);
        optionalField(8, position, pstmt);
        
        pstmt.setInt(9, contactPref);
        optionalField(10, notes, pstmt);        
        pstmt.setInt(11, personId); 
        pstmt.executeUpdate();

        return pstmt.toString();
    } catch (SQLException e) {
        e.printStackTrace(); // Handle or log the exception as needed
        return e.getMessage();
    }    
}



    private void optionalField(int paramIndex, String data, PreparedStatement stmt){

        try{

            if(data != null && data.length() != 0)
                stmt.setString(paramIndex, data);
            else
                stmt.setNull(paramIndex, Types.OTHER);
           
        } catch (SQLException e) {
            System.out.println("Exception @ optionalField");
            System.out.println(e.getMessage());  
        }
    }    

    public int addPerson(   String type, String firstName, String lastName, String middleName, String suffix, 
                            String sex, String birthDate, String company, String position, String notes, 
                            int addressId, int contactPref){
        Name name = new Name(firstName, middleName, lastName, suffix);

        
         if(company != null && company.length() != 0)
             company = validation.lengthTruncate(company, 45);
        
         if(position != null && position.length() != 0)
             position = validation.lengthTruncate(position, 45);
        
         return addPersonToDB(type, name.getFirst(), name.getLast(), name.getMiddle(), name.getSuffix(), sex, birthDate, company, position, notes, addressId, contactPref);
    }

    public boolean validateName(String firstName, String middleName, String lastName, String suffix){
        Name name = new Name(firstName, middleName, lastName, suffix);
        
        return (name.isValid());
    }


    public String getOneCell(String sqlStatement, int id){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;

        try{
            stmt = conn.prepareStatement(sqlStatement);
            stmt.setInt(1, id);

            rs = stmt.executeQuery();

            if (rs.next()) 
                return rs.getString("data");
            
            rs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCell");
            System.out.println(e);
        }

        return null;
    }

    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }
    
    public String getAddressId(int id){
        return getOneCell(sqlGetAddressId, id);
    }

    public String getContactPrefId(int id){
        return getOneCell(sqlGetContactPrefId, id);
    }
    
    public ArrayList<String> retrievePersonList() {
        return getDropDown(sqlPersonsNotDel);
    }

    public ArrayList<String> getTaskablePeople(){
        return getDropDown(sqlGetTaskablePerson);
    }

    public String deletePerson(int personId, String currentAssignment){
        Assignment assignment = new Assignment();
        Connection conn = connectToDB();
        
        if(conn == null)
            return null;

        try{
            PreparedStatement stmt = conn.prepareStatement(sqlDeletePerson);
            stmt.setString(1, validation.generateTimestamp());
            stmt.setString(2, String.valueOf(personId));

            stmt.executeUpdate();
            
            if(currentAssignment != null)
                assignment.endAssignment(Integer.parseInt(currentAssignment));

            return stmt.toString();

        } catch (SQLException e) {
            System.out.println("Exception @ deletePerson");
            System.out.println(e.getMessage());  
            return null;
        }
        
        

    }
}

