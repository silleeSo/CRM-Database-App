/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package crm_db;
import java.sql.*;

/**
 *
 * @author USER
 */
public class CampaignMembership {
    

    private IDGenerator idGen;
    private final String sqlInsertMembership = "INSERT INTO CampaignMembership VALUES (?, ?, ?, ?, NULL);";
    private Validation validator;


    public CampaignMembership(){
        idGen = new IDGenerator("campaignMembershipId", "CampaignMembership");
        validator = new Validation();
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    public boolean addCampaignMembership(int campaignId, int assignmentId){
        Connection conn = connectToDB();
        PreparedStatement insertCampaignStmt;
        int campaignMembershipId = idGen.getNextId();

        if(conn == null)
            return false;

        try{
            insertCampaignStmt = conn.prepareStatement(sqlInsertMembership);
            insertCampaignStmt.setInt(1, campaignMembershipId);
            insertCampaignStmt.setInt(2, campaignId);
            insertCampaignStmt.setInt(3, assignmentId);
            insertCampaignStmt.setString(4, validator.generateTimestamp());

            insertCampaignStmt.executeUpdate();

            insertCampaignStmt.close();
            conn.close();
            return true;

        } catch (SQLException e){
            System.out.println("Exception @ addCampaignMembership");
            System.out.println(e);
        } 
        return false;
    }
   
}
