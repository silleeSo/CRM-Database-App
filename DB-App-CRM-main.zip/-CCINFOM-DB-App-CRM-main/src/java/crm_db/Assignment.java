/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crm_db;

import java.sql.*;
import java.util.ArrayList;


/**
 *
 * @author USER
 */
public class Assignment {
   
    private final String sqlInsertAssignment = "INSERT INTO Assignment VALUES (?, ?, ?, NULL, ?)";
    private final String sqlInsertLeadAssignment = "INSERT INTO LeadAssignment VALUES (?, ?);";
    private final String sqlInsertCustomerAssigment = "INSERT INTO CustomerAssignment VALUES (?, ?);";
    private final String sqlEndAssignment = "UPDATE Assignment SET endDate = ? WHERE assignmentId = ?;";
    private final String sqlGetPersonFromAssignment = "(SELECT CONCAT(lastName, ', ',firstName) AS data FROM LeadAssignment la JOIN Lead l ON la.leadNumber = l.leadNumber JOIN Person p ON p.personId = l.personId WHERE assignmentId = ?) UNION ALL (SELECT CONCAT(lastName, ', ',firstName) AS personName FROM CustomerAssignment ca JOIN Customer c ON c.customerNumber = ca.customerNumber JOIN Person p ON p.personId = c.personId WHERE assignmentId = ? )"; 
    private final String sqlGetAssignmentFromPerson = "(SELECT a.assignmentId AS data FROM Assignment a JOIN LeadAssignment la ON la.assignmentId = a.assignmentId JOIN Lead l ON la.leadNumber = l.leadNumber JOIN Person p ON p.personId = l.personId WHERE a.endDate IS NULL AND p.deletedAt IS NULL AND CONCAT(lastName, ', ',firstName) = ? ) UNION ALL (SELECT  a.assignmentId AS dropDown FROM Assignment a JOIN CustomerAssignment ca  ON ca.assignmentId = a.assignmentId JOIN Customer c ON c.customerNumber = ca.customerNumber JOIN Person p ON p.personId = c.personId WHERE a.endDate IS NULL AND p.deletedAt IS NULL AND CONCAT(lastName, ', ',firstName) = ? )";


    private IDGenerator idGen;
    
    private Validation validator;

    public Assignment(){
        idGen = new IDGenerator("assignmentId", "Assignment");
        validator = new Validation();
    }
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    private int addAssignment(int employeeId, String type){
        Connection conn = connectToDB();
        PreparedStatement insertAssignmentStmt;
        int assignmentId = idGen.getNextId();

        if(conn == null)
            return -1;
        try{
            insertAssignmentStmt = conn.prepareStatement(sqlInsertAssignment);
            insertAssignmentStmt.setInt(1, assignmentId);
            insertAssignmentStmt.setInt(2, employeeId);
            insertAssignmentStmt.setString(3, validator.generateCurrentDate());
            insertAssignmentStmt.setString(4, type);

            insertAssignmentStmt.executeUpdate();
            insertAssignmentStmt.close();
            conn.close();

            return assignmentId;
        } catch (SQLException e){
            System.out.println("Exception @ addAssignment");
            System.out.println(e);
        }

        return -1;
    }

    private boolean specializedAssignment(int personNumber, int employeeId, String type, int currentAssignment){
        Connection conn = connectToDB();
        PreparedStatement insertSpecializedAssignmentStmt;

        if(conn == null)
            return false;

        int assignmentId = addAssignment(employeeId, type);

        try{

            if(type.equals("L"))
                insertSpecializedAssignmentStmt = conn.prepareStatement(sqlInsertLeadAssignment);
            else
                insertSpecializedAssignmentStmt = conn.prepareStatement(sqlInsertCustomerAssigment);

            insertSpecializedAssignmentStmt.setInt(1, assignmentId);
            insertSpecializedAssignmentStmt.setInt(2, personNumber);

            insertSpecializedAssignmentStmt.executeUpdate();
            insertSpecializedAssignmentStmt.close();
            conn.close();
            
            if(currentAssignment != -1)
                endAssignment(currentAssignment);
                    
            return true;
        } catch (SQLException e){
            System.out.println("Exception @ specializedAssignment");
            System.out.println(e);
        }

        return false;        
    }

    public boolean addLeadAssignment(int leadNumber, int employeeId, int currentAssignment){
        return specializedAssignment(leadNumber, employeeId, "L", currentAssignment);
    }

    public boolean addCustomerAssignment(int customerNumber, int employeeId, int currentAssignment){
        return specializedAssignment(customerNumber, employeeId, "C", currentAssignment);
    }


    public boolean endAssignment(int assignmentId){
        Connection conn = connectToDB();
        PreparedStatement endAssignmentStmt;
        
        if(conn == null)
            return false;
        
        try{
            endAssignmentStmt = conn.prepareStatement(sqlEndAssignment);
            endAssignmentStmt.setString(1, validator.generateCurrentDate());
            endAssignmentStmt.setInt(2, assignmentId);
            
            endAssignmentStmt.executeUpdate();
            endAssignmentStmt.close();
            conn.close();
            return true;
        } catch (SQLException e){
            System.out.println("Exception @ endAssignment");
            System.out.println(e);
        }
        return false;
    }

    public ArrayList<ArrayList<String>> extractList(ResultSet assignmentRs){
        ArrayList<ArrayList<String>> assignment = new ArrayList<>();
        
        try {
            while (assignmentRs.next()) {
                ArrayList<String> assignRow = new ArrayList<>();
                assignRow.add(assignmentRs.getString("lastName"));
                assignRow.add(assignmentRs.getString("firstName"));
                assignRow.add(assignmentRs.getString("assignmentId"));

                assignment.add(assignRow);
        
                for (ArrayList<String> assign : assignment) {
                    for (String assignData : assign)
                        System.out.print(assignData + " ");
                    System.out.println();
                }
            }

        } catch (SQLException e) {
            System.out.println("Exception @ extractList");
            e.printStackTrace();
        }

        return assignment;
    
    }

    
    public ArrayList<ArrayList<String>> retrieveAssignmentFromDB(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement getAssignment;
        ResultSet assignmentRs;
        ArrayList<ArrayList<String>> assignment;

        
        if (conn == null)
            return null;

        try {
            getAssignment = conn.prepareStatement(sqlStatement);

            assignmentRs = getAssignment.executeQuery();

            assignment = extractList(assignmentRs);


            getAssignment.close();
            conn.close();

            return assignment;

        } catch (SQLException e) {
            System.out.println("Exception @ retrieveLeads");
            System.out.println(e);
        }

        return null;
    }

    public String getOneCellTwoID(String sql, String id){
        Connection conn = connectToDB();
        PreparedStatement getContactStmt;
        ResultSet contactRs;

        try{
            getContactStmt = conn.prepareStatement(sql);
            getContactStmt.setString(1, id);
            getContactStmt.setString(2, id);


            contactRs = getContactStmt.executeQuery();

            if (contactRs.next()) 
                return contactRs.getString("data");
            
            contactRs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCellTwoID");
            System.out.println(e);
        }

        return null;
    }

    public String getPersonNameFromAssignment(String id){
        return getOneCellTwoID(sqlGetPersonFromAssignment, id);
    }

    
    public String getAssignmentFromPerson(String person){
        return getOneCellTwoID(sqlGetAssignmentFromPerson, person);
    }

}
