
package crm_db;
import java.sql.*;
 
public class Tags {
    private final String sqlInsert = "INSERT INTO Tags VALUES (?, ?, NULL);";

    Validation validator;
    
    public Tags(){
        validator = new Validation();
    }
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    public boolean addTag(String tag, int personId){
        Connection conn = connectToDB();
        PreparedStatement insertStmt;    
        //isPersonValid
        if(conn == null)
            return false;
         try{
            insertStmt = conn.prepareStatement(sqlInsert);
            insertStmt.setString(1, tag);
            insertStmt.setInt(2, personId);

            insertStmt.executeUpdate();
            insertStmt.close();
            conn.close();
            return true;
        }
        catch (SQLException e) {
            System.out.println("Exception @ addTag");
            System.out.println(e.getMessage());  
            return false;
        }
    }
}
