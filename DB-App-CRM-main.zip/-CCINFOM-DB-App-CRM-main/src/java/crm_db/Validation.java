/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */

package crm_db;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.regex.*;

public class Validation {

	private final int MOBILE_NO_LENGTH = 10;
	private final String URL_REGEX =  "^www\\.[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";


	public Validation() {
	// Pattern pattern = Pattern.compile(URL_REGEX);


	}


	public String emailValidation(String emailString) {
		// add pa later
		return emailString.toLowerCase();
	}

	public Boolean profileLinkValidation(String linkString) {
		// auto-detect if may https:// tanggalin yung para www lang
		// check if 45 chars lang
		// if(linkString.startsWith("https://"))
		// 	linkString.substring(8);
				
		// // else if(linkString.startsWith("www."))

		// if(linkString.startsWith("www."))

		// return false;
	}

	// check if 9 digits
	public Boolean mobileNoValidation(long mobileNo){
		String mobileString = String.valueOf(mobileNo);
		if(mobileString.startsWith("9"))
			return lengthValidation (mobileString, MOBILE_NO_LENGTH, true);
		return false;
	}

	public Boolean lengthValidation(String testString, int length, boolean isEqualOnly){
		if(isEqualOnly)
			return testString.length() == length;
		return testString.length() < length;
	}

	public String lengthTruncate(String testString, int newLength){
		if(testString.length() > newLength)
				return testString.substring(0, newLength);
		return testString;
	}
	
	public String generateTimestamp(){
            return new SimpleDateFormat("YYYY-MM-dd HH:mm:ss").format(new Date());
        }
        
        public String generateCurrentDate(){
            return new SimpleDateFormat("YYYY-MM-dd").format(new Date());
        }
	
	public boolean isAlpha(String string){
		
		if(string == null || string.length() == 0 || string.isEmpty() || string.trim().length() == 0)
			return false;
           
		int i;

		for(i = 0; i < string.length(); i++){
			if(!Character.isLetter(string.charAt(i)) && string.charAt(i) != ' ')
				return false;
		}

		return true;
	}
	
	public boolean zipValidation(int zipcode){
                String zipString = String.valueOf(zipcode);
		if (zipcode > 0 && lengthValidation(zipString, 4, true))
			return true;
		return false;
	}
	
	public static void main(String[] args){
		Validation validation = new Validation();

		System.out.println(validation.generateTimestamp());
		// System.out.println("Function: lengthTruncate");
		// System.out.println("testString=1234, newLength=3");        
		// System.out.println(validation.lengthTruncate("1234", 3));
		// System.out.println("testString=123, newLength=3");
		// System.out.println(validation.lengthTruncate("123", 3));
		// System.out.println("testString=12, newLength=3");
		// System.out.println(validation.lengthTruncate("12", 3));

		// TO-DO FOR lengthValidation

		// System.out.println("\nFunction: mobileNoValidation");
		// System.out.println("mobileNo=9305005490");        
		// System.out.println(validation.mobileNoValidation(9305005490l));
		// System.out.println("mobileNo=5305005490");        
		// System.out.println(validation.mobileNoValidation(5305005490l));
		// System.out.println("mobileNo=930500549");
		// System.out.println(validation.mobileNoValidation(930500549l));
		// System.out.println("mobileNo=530500549");
		// System.out.println(validation.mobileNoValidation(530500549l));

	}    
}
