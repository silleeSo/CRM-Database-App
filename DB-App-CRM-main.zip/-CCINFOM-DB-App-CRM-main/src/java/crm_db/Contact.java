
package crm_db;
import java.sql.*;

public class Contact{

    private final String sqlInsert =        "INSERT INTO Contact VALUES (?, ?, ?, ?, NULL);";
    private final String sqlUpdatePerson =  "UPDATE Contact SET personId = (?) WHERE contactId = (?);";
    private final String sqlInsertEmail =   "INSERT INTO Email VALUES (?, ?);";
    private final String sqlInsertMobileNo =   "INSERT INTO MobileNo VALUES (?, ?);";
    private final String sqlInsertSocial =  "INSERT INTO Social VALUES (?, ?);";
    private final String sqlEmailCount = "SELECT COUNT(*) as count FROM Email WHERE email = ?";
    private final String sqlMobileNoCount = "SELECT COUNT(*) as count FROM MobileNo WHERE mobileNo = ?";
    private final String sqlSocialCount = "SELECT COUNT(*) as count FROM Social WHERE profileLink = ?";
    private final String sqlContactCount = "SELECT COUNT(*) isNotUnique FROM ( (SELECT contactId, email as contact FROM Email) UNION ALL (SELECT contactId, mobileNo as contact FROM MobileNo) UNION ALL (SELECT contactId, profileLink as contact FROM Social) ) jc where contact = ?;";
    private final String sqlGetEmail = "SELECT email as data FROM Email e JOIN Contact c ON c.contactId = e.contactId WHERE personId = ?;";
    private final String sqlGetMobileNo = "SELECT mobileNo as data FROM MobileNo m JOIN Contact c ON c.contactId = m.contactId WHERE personId = ?;";
    private final String sqlGetSocial = "SELECT profileLink as data FROM Social s JOIN Contact c ON c.contactId = s.contactId WHERE personId = ?;";
    private final String sqlDeleteEmail = "DELETE e, c FROM Email AS e JOIN Contact AS c ON e.contactId = c.contactId WHERE e.email = ?;";
    private final String sqlDeleteSocial = "DELETE s, c FROM Social AS s JOIN Contact AS c ON s.contactId = c.contactId WHERE s.profileLink = ?;";
    private final String sqlDeleteMobileNo = "DELETE m, c FROM MobileNo AS m JOIN Contact AS c ON m.contactId = c.contactId WHERE m.mobileNo = ?;"; 
    private final String sqlUpdateEmail = "UPDATE Email SET email = ? WHERE email = ?;";
    private final String sqlUpdateSocial = "UPDATE Social SET profileLink = ? WHERE profileLink = ?;";
    private final String sqlUpdateMobile = "UPDATE MobileNo SET mobileNo = ? WHERE mobileNo = ?;";

    private Validation validation;
    private IDGenerator generate;

    public Contact(){
        validation = new Validation();
        generate = new IDGenerator("contactId", "Contact");
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }


    public int addContact(String sqlStatement, String type, String contact){
        Connection conn = connectToDB();
        PreparedStatement insertStmt;    
        int nextId = generate.getNextId();

        if(conn == null)
            return 0;

        try{
            insertStmt = conn.prepareStatement(sqlInsert);
            insertStmt.setInt(1, nextId);
            insertStmt.setNull(2, Types.INTEGER);
            insertStmt.setString(3, type);
            insertStmt.setString(4, validation.generateTimestamp());
            

            insertStmt.executeUpdate();
            insertStmt.close();

            addContactType(conn, sqlStatement, nextId, contact);
            conn.close();
            return nextId;

        } catch (SQLException e) {
            System.out.println("Exception @ addContact");
            System.out.println(e.getMessage());  
            return 0;
        }
    }

    public String getOneCell(String sqlStatement, int id){
        Connection conn = connectToDB();
        PreparedStatement getContactStmt;
        ResultSet contactRs;

        try{
            getContactStmt = conn.prepareStatement(sqlStatement);
            getContactStmt.setInt(1, id);

            contactRs = getContactStmt.executeQuery();

            if (contactRs.next()) 
                return contactRs.getString("data");
            
            contactRs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCell");
            System.out.println(e);
        }

        return null;
    }

    public boolean deleteContact(String sql, String contact) {
        Connection conn = connectToDB();
        PreparedStatement deleteStmt;
    
        try {
            deleteStmt = conn.prepareStatement(sql);
            deleteStmt.setString(1, contact);
    
            deleteStmt.executeUpdate();
    
            deleteStmt.close();
            conn.close();
            return false;
        } catch (SQLException e) {
            System.out.println("Exception @ deleteContact");
            System.out.println(e);
        }
        return true;
    }

    
    public String updateContact(String sql, String newContact, String id) {
        Connection conn = connectToDB();
        PreparedStatement updateStmt;
    
        try {
            updateStmt = conn.prepareStatement(sql);
            updateStmt.setString(1, newContact);
            updateStmt.setString(2, id);
            
    
            updateStmt.executeUpdate();
    
            updateStmt.close();
            conn.close();
            return null;
        } catch (SQLException e) {
            System.out.println("Exception @ updateContact");
            System.out.println(e);
            return e.getMessage();

        }
        
    }

    public String updateEmail(String email, String id){
        return updateContact(sqlUpdateEmail, email, id);
    }
    public String updateSocial(String social, String id){
        return updateContact(sqlUpdateSocial, social, id);
    }
    public String updateMobile(String mobileNo, String id){
        return updateContact(sqlUpdateMobile, mobileNo, id);
    }

    public boolean deleteEmail(String email){
        return deleteContact(sqlDeleteEmail, email);
    }
    
    
    public boolean deleteMobile(String mobileNo){
        return deleteContact(sqlDeleteMobileNo, mobileNo);
    }

    
    public boolean deleteSocial(String social){
        return deleteContact(sqlDeleteSocial, social);
    }

    public String getEmail(int id){
        return getOneCell(sqlGetEmail, id);
    }

    
    public String getMobileNo(int id){
        return getOneCell(sqlGetMobileNo, id);
    }

    public String getSocial(int id){
        return getOneCell(sqlGetSocial, id);
    }

    public boolean isUnique(String sqlStatement, String data){
        Connection conn = connectToDB();
        PreparedStatement isUniqueStmt;
        ResultSet isUniqueRs;


        if(conn == null)
            return false;
        
  

        try{

            isUniqueStmt = conn.prepareStatement(sqlStatement);
            isUniqueStmt.setString(1, data); 
            
            isUniqueRs = isUniqueStmt.executeQuery();

            if (isUniqueRs.next()) 
                return isUniqueRs.getInt("count") == 0;
            

            isUniqueStmt.close();
            conn.close();

        } catch (SQLException e){
            System.out.println("Exception @ isUnique");
            System.out.println(e);
        }

        return false;
    }
    
    public boolean addContactType(Connection conn, String sqlStatement, int contactId, String contact){
        PreparedStatement insertContactTypeStmt;

        if(conn == null)
            return false;
        
        try{
            insertContactTypeStmt = conn.prepareStatement(sqlStatement);
            insertContactTypeStmt.setInt(1, contactId);
            insertContactTypeStmt.setString(2, contact);
            insertContactTypeStmt.executeUpdate();
            insertContactTypeStmt.close();
            return true;
        }
        catch (SQLException e){
            System.out.println("Exception @ addContactType");
            System.out.println(sqlStatement);
            System.out.println(e.getMessage());  
            return false;
        }
    }

    public boolean addPersonToContact(int contactId, int personId){
        // who calls this: contacts with no null personId
        // call the method to check if the person is deletedAt
        Connection conn = connectToDB();
        PreparedStatement updateStmt;    

        if(conn == null)
            return false;

        try{
            updateStmt = conn.prepareStatement(sqlUpdatePerson);
            updateStmt.setInt(1, personId);
            updateStmt.setInt(2, contactId);

            updateStmt.executeUpdate();
            updateStmt.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Exception @ addPersonToContact");
            System.out.println("Exception");
            System.out.println(e.getMessage());  


            return false;
        }

        
    }

    public boolean isUniqueContact(String mobileNo){
        Connection conn = connectToDB();
        PreparedStatement isUniqueStmt;
        ResultSet isUniqueRs;


        if(conn == null)
            return false;

        try{
            isUniqueStmt = conn.prepareStatement(sqlContactCount);
            isUniqueStmt.setString(1, mobileNo);
            isUniqueRs = isUniqueStmt.executeQuery();

            if(isUniqueRs.next())
                return isUniqueRs.getString("isNotUnique").equals("0");
            
            isUniqueStmt.close();
            conn.close();

            return true;
            
        } catch (SQLException e) {
            System.out.println("Exception @ isUniqueContact");
            System.out.println("Exception");
            System.out.println(e.getMessage());  


            return false;
        }
    }

    public int addContact(String sqlStatement, String type, String contact, int personId){
        int contactId = addContact(type, sqlStatement, contact);
        addPersonToContact(contactId, personId);
        return contactId;
    }

    public int addEmail(String email){
        if(email.length() == 0 || !isUnique(sqlEmailCount, email))
            return 0;
        return addContact(sqlInsertEmail, "E", email);
    }
    
    public int addSocial(String social){
        if(social.length() == 0 || !isUnique(sqlSocialCount, social))
            return 0;
        return  addContact(sqlInsertSocial, "S", social);
    }

    
    public int addMobileNo(long mobileNo){
        String sMobileNo = String.valueOf(mobileNo);
        if(!validation.mobileNoValidation(mobileNo) || !isUnique(sqlMobileNoCount, sMobileNo))
            return 0;
        
        return addContact(sqlInsertMobileNo, "M", sMobileNo);
    }


    
}