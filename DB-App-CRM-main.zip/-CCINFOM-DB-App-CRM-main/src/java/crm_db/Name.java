/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
package crm_db;
public class Name {
    
    private String first;
    private String last;
    private String middle;
    private String suffix;
    private Validation validator;
    
//    private final String[] possibleSuffices = {};
    
    
    public Name(String first, String middle, String last, String suffix){
        validator = new Validation();
        
        System.out.println(validateName(first, middle, last, suffix));
        if(!(validateName(first, middle, last, suffix) == 1))
            return;
        
        this.first = cleanName(first);
        this.middle = cleanName(middle);
        this.last = cleanName(last);
        this.suffix = cleanName(suffix);
    }
    
    public boolean isValid(){
        return (first != null) && (last != null);
    }
    
    public int validateName(String first, String middle, String last, String suffix){
        if(!validator.isAlpha(first))
            return -1;
    
        if(!validator.isAlpha(last))
            return -2;
        

        if(!(middle == null || middle.length() == 0))
            if(!validator.isAlpha(middle))
                return -3;

        if(!(suffix == null || suffix.length() == 0))
            if(!validator.isAlpha(suffix))
                return -4;

        return 1;
    }
    
    private String cleanName(String namePart) {
        if (namePart != null && namePart.length() != 0) {
            namePart = namePart.substring(0, 1).toUpperCase() + namePart.substring(1); // Capitalizing first letter
            return validator.lengthTruncate(namePart, 45); // Truncating if needed
        }
        return "";
    }
    

    public String getFirst(){
        return first;
    }

    public String getMiddle(){
        return middle;
    }
    
    public String getLast(){
        return last;
    }

    public String getSuffix(){
        return suffix;
    }
    
    
}
