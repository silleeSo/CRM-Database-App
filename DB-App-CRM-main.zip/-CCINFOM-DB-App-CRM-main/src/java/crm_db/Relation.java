package crm_db;

import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class Relation {
    
    private IDGenerator idGen;
    private final String sqlInsertRelation = "INSERT INTO Relation VALUES (?, ?, ?, ?, ?, NULL);";
    
    public Relation(){
        idGen = new IDGenerator("RelationId", "Relation");
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    
    public boolean addRelation(int campaignMembershipId, String relationDate, int modeOfContact, int isSuccessful){
        Connection conn = connectToDB();
        PreparedStatement insertRelationStmt;
        int relationId = idGen.getNextId();
        
        if(conn == null)
            return false;
        
        try{
            insertRelationStmt = conn.prepareStatement(sqlInsertRelation);
            insertRelationStmt.setInt(1, relationId);
            insertRelationStmt.setInt(2, campaignMembershipId);
            insertRelationStmt.setString(3, relationDate);
            insertRelationStmt.setInt(4, modeOfContact);
            insertRelationStmt.setInt(5, isSuccessful);
            insertRelationStmt.executeUpdate();

            insertRelationStmt.close();
            conn.close();

            return true;
            
        } catch(SQLException e){
            System.out.println("Exception @ addRelation");
            System.out.println(e);
        }
        return false;
    }
    
    
}
