/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crm_db;
import java.sql.*;

/**
 *
 * @author USER
 */
public class Campaign {
    
    private IDGenerator idGen;
    private final String sqlInsertCampaign = "INSERT INTO Campaign VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL);";
    private final String sqlUpdateCampaignName = "UPDATE Campaign SET campaignName = ? WHERE campaignId = ?";
    private final String sqlUpdateDescription = "UPDATE Campaign SET description = ? WHERE campaignId = ?";
    private final String sqlUpdateStatus = "UPDATE Campaign SET status = ? WHERE campaignId = ?";
    private final String[] sqlUpdates = new String[]{sqlUpdateCampaignName, sqlUpdateDescription, sqlUpdateStatus};
    
    
    public Campaign(){
        idGen = new IDGenerator("campaignId", "Campaign");
    }   
    
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    public boolean addCampaign(int employeeId, String campaignName, String description, String startDate, String endDate, double forecastedRevenue, String status){
        // date could be in the future 
        Connection conn =  connectToDB();
        PreparedStatement insertCampaignStmt;
        int campaignId = idGen.getNextId();

        if(conn == null)
            return false;

        try{
            insertCampaignStmt = conn.prepareStatement(sqlInsertCampaign);
            insertCampaignStmt.setInt(1, campaignId);
            insertCampaignStmt.setInt(2, employeeId);
            insertCampaignStmt.setString(3, campaignName);
            insertCampaignStmt.setString(4, description);
            insertCampaignStmt.setString(5, startDate);
            if(endDate != null)
                insertCampaignStmt.setString(6, endDate);
            else
                insertCampaignStmt.setNull(6, Types.VARCHAR);
            insertCampaignStmt.setDouble(7, forecastedRevenue);
            insertCampaignStmt.setString(8, status);

            insertCampaignStmt.executeUpdate();

            insertCampaignStmt.close();
            conn.close();

            return true;
        } catch (SQLException e){
            System.out.println("Exception @ addCampaign");
            System.out.println(e);
        }

        return false;
    }

    public boolean editCampaignDetail(int campaignID, String data, int paramIndex){
        Connection conn = connectToDB();
        PreparedStatement updateCampaignDetailStmt;

        if(conn == null)
            return false;

        try{
            updateCampaignDetailStmt = conn.prepareStatement(sqlUpdates[paramIndex]);
            updateCampaignDetailStmt.setString(1, data);
            updateCampaignDetailStmt.setInt(2, campaignID);

            updateCampaignDetailStmt.executeUpdate();
            updateCampaignDetailStmt.close();
            conn.close();
            return true;

        } catch (SQLException e){
            System.out.println("Exception @ editCampaignName");
            System.out.println(e);
        }
        return false;
    }

}
