
package crm_db;
import java.sql.*;
import java.util.*;
 
public class Employee {
    private final String sqlInsert =        "INSERT INTO Employee VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL);";
    private final String sqlUpdate =        "UPDATE Employee SET lastName = ?, firstName = ?, middleName=?, suffix =?, birthday = ?, sex = ?, position = ? WHERE employeeId = ?;";
    private final String sqlUpdatePosition =  "UPDATE Employee SET position = (?) WHERE employeeId = (?);";
    private final String sqlDeletedAt =  "UPDATE Employee SET deletedAt = (?) WHERE employeeId = (?);";
    private final String sqlEndAssignment =  "UPDATE Assignment SET endDate = (?) WHERE employeeId = (?);";
    private final String sqlDeleteTask =  "UPDATE Tasks SET deletedAt = (?) WHERE assignmentId = (?);";
    private final String sqlEmployeeAssignments = "SELECT assignmentId FROM Assignment WHERE employeeId = ?;";
    private final String sqlGetTotalRecords = "SELECT COUNT(*) AS totalRecords FROM Employee;";
    private final String sqlGetAssignmentCount = "SELECT COUNT(*) AS count FROM assignment WHERE employeeId = ? AND type = ?;";
    private final String sqlGetGenRevenue = "SELECT SUM(od.pricePerPiece * od.quantity) AS generatedRevenue FROM (((orderdetail od JOIN orders o ON od.orderNumber = o.orderNumber)  JOIN customerassignment ca ON ca.assignmentId = o.marketingId) JOIN assignment a ON a.assignmentId = ca.assignmentId) WHERE o.status = \"completed\" GROUP BY a.employeeId HAVING employeeId = ?;";
    
    private final String sqlCountSimilarEmployee = "SELECT COUNT(*) AS count FROM Employee WHERE lastName = ? AND firstName = ? AND middleName = ? AND suffix = ? AND birthday = ? AND sex = ?;";
    private final String sqlGetSimilarEmployeeNum = "SELECT employeeId AS count FROM Employee WHERE lastName = ? AND firstName = ? AND middleName = ? AND suffix = ? AND birthday = ? AND sex = ?;";
    private final String sqlGetSimilarEmployeeNumNoSuffix = "SELECT employeeId AS count FROM Employee WHERE lastName = ? AND firstName = ? AND middleName = ? AND suffix IS NULL AND birthday = ? AND sex = ?;";
    private final String sqlSelectEmployee = "SELECT * FROM Employee WHERE employeeId = ?;";
    private final String sqlSearchEmployee = "SELECT employeeId AS id FROM Employee WHERE lastName LIKE ? OR firstName LIKE ? OR middleName LIKE ? OR (suffix IS NOT NULL AND suffix LIKE ?);";
    
    Validation validator;
    private IDGenerator generate;
    
    public final Comparator<ArrayList<String>> leadsComparator = new Comparator<ArrayList<String>>() {
        @Override
        public int compare(ArrayList<String> o1, ArrayList<String> o2) {
                return o1.get(2).compareTo(o2.get(2));
        } 
    };
    public final Comparator<ArrayList<String>> customersComparator = new Comparator<ArrayList<String>>() {
        @Override
        public int compare(ArrayList<String> o1, ArrayList<String> o2) {
                return o1.get(3).compareTo(o2.get(3));
        } 
    };
    public final Comparator<ArrayList<String>> revenueComparator = new Comparator<ArrayList<String>>() {
        @Override
        public int compare(ArrayList<String> o1, ArrayList<String> o2) {
                return o1.get(4).compareTo(o2.get(4));
        } 
    };
    
    public Employee(){
        validator = new Validation();
        generate = new IDGenerator("employeeId", "Employee");
        
    }
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    // add employee
    //turn all strings into length 45
    //have timestamp for creation
    public int addEmployee(String lastName, String firstName, String middleName, String suffix, String birthday, String sex, String position){
        Connection conn = connectToDB();
        PreparedStatement insertStmt;    
        int nextId = generate.getNextId();
        
        if(conn == null)
            return 0;
        if (suffix.equals("none"))
            suffix = null;
        Name name = new Name(firstName, middleName, lastName, suffix);

        position = validator.lengthTruncate(position, 45);
            
        try{
            insertStmt = conn.prepareStatement(sqlInsert);
            insertStmt.setInt(1, nextId);         
            insertStmt.setString(2, name.getLast());
            insertStmt.setString(3, name.getFirst());
            insertStmt.setString(4, name.getMiddle());
            if (name.getSuffix().equals(""))
                insertStmt.setNull(5, Types.VARCHAR);
            else
                insertStmt.setString(5, name.getSuffix());
            insertStmt.setString(6, birthday);
            insertStmt.setString(7, sex);
            insertStmt.setString(8, position);
            insertStmt.setString(9, validator.generateTimestamp());

            insertStmt.executeUpdate();
            insertStmt.close();
            conn.close();
            return nextId;
        }
        catch (SQLException e) {
            System.out.println("Exception @ addEmployee");
            System.out.println(e.getMessage());  
            return 0;
        }
        
    }
    public boolean updateEmployee(int employeeId, String lastName, String firstName, String middleName, String suffix, String birthday, String sex, String position){
        Connection conn = connectToDB();
        PreparedStatement updateStmt;    
        
        if(conn == null)
            return false;
        if (suffix.equals("none"))
            suffix = null;
        Name name = new Name(firstName, middleName, lastName, suffix);

        position = validator.lengthTruncate(position, 45);
            
        try{
            updateStmt = conn.prepareStatement(sqlUpdate);
                     
            updateStmt.setString(1, name.getLast());
            updateStmt.setString(2, name.getFirst());
            updateStmt.setString(3, name.getMiddle());
            if (name.getSuffix().equals(""))
                updateStmt.setNull(4, Types.VARCHAR);
            else
                updateStmt.setString(4, name.getSuffix());
            updateStmt.setString(5, birthday);
            updateStmt.setString(6, sex);
            updateStmt.setString(7, position);
            updateStmt.setInt(8, employeeId);

            updateStmt.executeUpdate();
            updateStmt.close();
            conn.close();
            return true;
            
        }
        catch (SQLException e) {
            System.out.println("Exception @updateEmployee");
            System.out.println(e.getMessage());  
            return false;
        }
        
    }
    public boolean updatePosition(int employeeId, String newPosition){
        Connection conn = connectToDB();
        PreparedStatement updatePositionStmt;
        
        if (conn == null)
            return false;
        try{
            updatePositionStmt = conn.prepareStatement(sqlUpdatePosition);
            updatePositionStmt.setString(1, newPosition);
            updatePositionStmt.setInt(2, employeeId);
            updatePositionStmt.executeUpdate();
            updatePositionStmt.close();
            return true;
        }
        catch (SQLException e){
            System.out.println("Exception @ updatePosition");
            System.out.println(e.getMessage());  
            return false;
        }
    }
    public int getTotalEmployees(){
        ResultSet rst;
        int total = 0;
        Connection conn = connectToDB();
        PreparedStatement getTotalStmt;
        if (conn == null)
            return -1;
        try{
            
            getTotalStmt = conn.prepareStatement(sqlGetTotalRecords);
            rst = getTotalStmt.executeQuery();
            while (rst.next()){
                total = rst.getInt("totalRecords");
            }
            getTotalStmt.close();
            return total;
        }
        catch (SQLException e){
            System.out.println("Exception @ returnTotalEmployees");
            System.out.println(e.getMessage());  
            return -1;
        }
        
    }
    public int getNumOfLeads(int employeeId){
        ResultSet rst;
        int count = 0;
        Connection conn = connectToDB();
        PreparedStatement getCountStmt;
        
        if (conn == null)
            return -1;
        try{
            getCountStmt = conn.prepareStatement(sqlGetAssignmentCount);
            getCountStmt.setInt(1, employeeId);
            getCountStmt.setString(2, "L");
            rst = getCountStmt.executeQuery();
            while (rst.next()){
                count = rst.getInt("count");
            }
            getCountStmt.close();
            return count;
        }
        catch (SQLException e){
            System.out.println("Exception @ getNumOfLeads");
            System.out.println(e.getMessage());  
            return -1;
        }
    }
    
    public int getNumOfCustomers(int employeeId){
        ResultSet rst;
        int count = 0;
        Connection conn = connectToDB();
        PreparedStatement getCountStmt;
        
        if (conn == null)
            return -1;
        try{
            getCountStmt = conn.prepareStatement(sqlGetAssignmentCount);
            getCountStmt.setInt(1, employeeId);
            getCountStmt.setString(2, "C");
            rst = getCountStmt.executeQuery();
            while (rst.next()){
                count = rst.getInt("count");
            }
            getCountStmt.close();
            return count;
        }
        catch (SQLException e){
            System.out.println("Exception @ getNumOfCustomers");
            System.out.println(e.getMessage());  
            return -1;
        }
    }
    public float getGeneratedRevenue(int employeeId){
        ResultSet rst;
        float totalRev = 0;
        Connection conn = connectToDB();
        PreparedStatement getRevStmt;
        
        if (conn == null)
            return -1;
        try{
            getRevStmt = conn.prepareStatement(sqlGetGenRevenue);
            getRevStmt.setInt(1, employeeId);
            rst = getRevStmt.executeQuery();
            while (rst.next()){
                totalRev = rst.getFloat("generatedRevenue");
            }
            getRevStmt.close();
            return totalRev;
        }
        catch (SQLException e){
            System.out.println("Exception @ getgeneratedRevenue");
            System.out.println(e.getMessage());  
            return -1;
        }
    }
    
    public boolean employeeExists(String lastName, String firstName, String middleName, String suffix, String birthday, String sex){
        ResultSet rst;
        int count = 0;
        Connection conn = connectToDB();
        PreparedStatement SimilarEmployeeCountStmt;
        if (suffix.equals("none"))
            suffix = null;
        Name name = new Name(firstName, middleName, lastName, suffix);
        if (conn == null)
            return false;
        
        try{
            if (suffix == null){
                SimilarEmployeeCountStmt = conn.prepareStatement(sqlGetSimilarEmployeeNumNoSuffix);
                SimilarEmployeeCountStmt.setString(4, birthday);
                SimilarEmployeeCountStmt.setString(5, sex);
            }
               
            else{
                SimilarEmployeeCountStmt = conn.prepareStatement(sqlCountSimilarEmployee);
                SimilarEmployeeCountStmt.setString(4, name.getSuffix());
                SimilarEmployeeCountStmt.setString(5, birthday);
                SimilarEmployeeCountStmt.setString(6, sex);
                
            }
            SimilarEmployeeCountStmt.setString(1, name.getLast());
            SimilarEmployeeCountStmt.setString(2, name.getFirst());
            SimilarEmployeeCountStmt.setString(3, name.getMiddle());
            
            
            rst = SimilarEmployeeCountStmt.executeQuery();
            while (rst.next()){
                count = rst.getInt("count");
            }
            SimilarEmployeeCountStmt.close();

            return count > 0;
        }
        catch (SQLException e){
            System.out.println("Exception @ employeeExists");
            System.out.println(e.getMessage());  
            return false;
        }
    }
public int getSimilarEmployeeNum(String lastName, String firstName, String middleName, String suffix, String birthday, String sex){
        ResultSet rst;
        int idNum = -1;
        Connection conn = connectToDB();
        PreparedStatement SimilarEmployeeStmt;
        Name name = new Name(firstName, middleName, lastName, suffix);
        if (conn == null)
            return -1;
        try{
            SimilarEmployeeStmt = conn.prepareStatement(sqlGetSimilarEmployeeNum);
            SimilarEmployeeStmt.setString(1, name.getLast());
            SimilarEmployeeStmt.setString(2, name.getFirst());
            SimilarEmployeeStmt.setString(3, name.getMiddle());
            if (name.getSuffix().equals(""))
                SimilarEmployeeStmt.setNull(4, Types.VARCHAR);
            else
                SimilarEmployeeStmt.setString(4, name.getSuffix());
            SimilarEmployeeStmt.setString(5, birthday);
            SimilarEmployeeStmt.setString(6, sex);
            rst = SimilarEmployeeStmt.executeQuery();
            while (rst.next()){
                idNum = rst.getInt("id");
            }
            SimilarEmployeeStmt.close();

            return idNum;
        }
        catch (SQLException e){
            System.out.println("Exception @getSimilarEmployeeNum");
            System.out.println(e.getMessage());  
            return -1;
        }
    }
    public boolean deleteEmployeeRecord(int employeeId){
        Connection conn = connectToDB();
        PreparedStatement Stmt;
        ResultSet rst;
        ArrayList<Integer> assignmentIds = new ArrayList<>();
        if (conn == null)
            return false;
        
        
        
        
        try{
            //edit employee table
            Stmt = conn.prepareStatement(sqlDeletedAt);
            Stmt.setString(1, validator.generateTimestamp());
            Stmt.setInt(2, employeeId);
            Stmt.executeUpdate();
            
            // get all assignmentIds with matching employeeId
            Stmt = conn.prepareStatement(sqlEmployeeAssignments);
            Stmt.setInt(1, employeeId);
            rst = Stmt.executeQuery();
            while (rst.next())
                assignmentIds.add(rst.getInt("assignmentId"));
            
            // edit assignments table
            Stmt = conn.prepareStatement(sqlEndAssignment);
            Stmt.setString(1, validator.generateCurrentDate());
            Stmt.setInt(2, employeeId);
            Stmt.executeUpdate();
            
            //use that list of assignments to update Tasks and delete them
            Stmt = conn.prepareStatement(sqlDeleteTask);
            for (int assignmentId : assignmentIds){
                Stmt.setString(1, validator.generateTimestamp());
                Stmt.setInt(2, assignmentId);
                Stmt.executeUpdate();
            }
                
            
            
            Stmt.close();
            return true;
        }
        catch (SQLException e){
            System.out.println("Exception @deleteEmployee");
            System.out.println(e.getMessage());  
            return false;
        }
    }
    
    public ArrayList<String> retrieveEmployee(int employeeId){
        ResultSet rst;
        Connection conn = connectToDB();
        PreparedStatement selectEmployeeStmt;
        ArrayList<String> employee = new ArrayList<>();    
         if (conn == null)
            return null;
        try{
            selectEmployeeStmt = conn.prepareStatement(sqlSelectEmployee);
            selectEmployeeStmt.setInt(1, employeeId);
            rst = selectEmployeeStmt.executeQuery();
            while (rst.next()){           
            employee.add(rst.getString("employeeId"));
            employee.add(rst.getString("lastName"));
            employee.add(rst.getString("firstName"));
            employee.add(rst.getString("middleName"));
            employee.add(rst.getString("suffix"));
            employee.add(rst.getString("birthday"));
            employee.add(rst.getString("sex"));
            employee.add(rst.getString("position"));
           
            employee.add(rst.getString("deletedAt"));}      
            selectEmployeeStmt.close();       
        }
        catch (SQLException e){
            System.out.println("Exception @retrieveEmployee");
            System.out.println(e.getMessage());  
            return null;
        }
        return employee;
    }
    
    public String getPosition(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(7);  
    }
    public String getFullName(int employeeId){
        return getFirstName(employeeId) + " " + getMiddleName(employeeId) + " " + getLastName(employeeId) + " " + getSuffix(employeeId); 
    }
    public String getFirstName(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(2); 
    }
    public String getMiddleName(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(3); 
    }
    public String getLastName(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(1); 
    }
    public String getSuffix(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
        String suffix;
        if (employee.get(4) == null)
            suffix ="";
        else
            suffix = employee.get(4);
        return suffix; 
    }
    public String getBirthday(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(5);  
    }
    public String getSex(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(6);  
    }
    public String getDeletedAt(int employeeId){
        ArrayList<String> employee = new ArrayList<>();
        employee = retrieveEmployee(employeeId);
       
        return employee.get(8);  
    }
    public boolean isEmployeeDeleted(int employeeId){
        String deletedAt = getDeletedAt(employeeId);
        
        if (deletedAt == null)
            return false;
        else 
            return true;
        
    }
    public ArrayList<String> getEmployeeRow(int employeeId){
        ArrayList<String> employeeRow = new ArrayList<>();
        employeeRow.add(String.valueOf(employeeId));
        employeeRow.add(String.valueOf(getFullName(employeeId)));
        employeeRow.add(String.valueOf(getNumOfLeads(employeeId)));
        employeeRow.add(String.valueOf(getNumOfCustomers(employeeId)));
        employeeRow.add(String.valueOf(getGeneratedRevenue(employeeId)));
        return employeeRow;
    }
    public ArrayList<ArrayList<String>> retrieveEmployees(){
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
        int numOfEmployees = getTotalEmployees();
        for (int i = 1; i <= numOfEmployees; i++){
            if (isEmployeeDeleted(i) == false){
                employeeList.add(getEmployeeRow(i));
            }
        }
        return employeeList;
    }
    
      
    public ArrayList<ArrayList<String>> retrieveEmployees(ArrayList<Integer> ids){

        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
        int numOfEmployees = ids.size();
        for (int i = 0; i < numOfEmployees; i++){
            int id = ids.get(i);
            if (isEmployeeDeleted(id) == false){
                employeeList.add(getEmployeeRow(id));
            }
        }
        return employeeList;
    }
    public ArrayList<ArrayList<String>> orderByLeads(boolean isDescending){
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
        employeeList = retrieveEmployees();
        
        Collections.sort(employeeList, leadsComparator);
        if (isDescending == true)
            Collections.reverse(employeeList);
        return employeeList;
    }
    public ArrayList<ArrayList<String>> orderByCustomers(boolean isDescending){
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
        employeeList = retrieveEmployees();
        
        Collections.sort(employeeList, customersComparator );
        if (isDescending == true)
            Collections.reverse(employeeList);
        return employeeList;
    }
    public ArrayList<ArrayList<String>> orderByRevenue(boolean isDescending){
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
        employeeList = retrieveEmployees();
        
        Collections.sort(employeeList, revenueComparator );
        if (isDescending == true)
            Collections.reverse(employeeList);
        return employeeList;
    }
    public ArrayList<ArrayList<String>> searchEmployee(String string){

        Connection conn = connectToDB();
        PreparedStatement SeacrhStmt;
        ResultSet searchRes;
        
        String likeString = "%" + string + "%";
        ArrayList<Integer> employeeIds = new ArrayList<>();
        if (conn == null)
            return null;

        try {
           
            SeacrhStmt = conn.prepareStatement(sqlSearchEmployee);
            SeacrhStmt.setString(1, likeString);
            SeacrhStmt.setString(2, likeString);
            SeacrhStmt.setString(3, likeString);
            SeacrhStmt.setString(4, likeString);
            
            searchRes = SeacrhStmt.executeQuery();
            
            while (searchRes.next()){
                employeeIds.add(searchRes.getInt("id"));
            }
            
            SeacrhStmt.close();
            conn.close();
            
            return retrieveEmployees(employeeIds);

        } catch (SQLException e) {
            System.out.println("Exception @searchEmployee");
            System.out.println(e);
            return null;
        }
    }
    public ArrayList<ArrayList<String>> filterByRange(double minVal, double maxVal, int attribute){

        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();;
        employeeList = retrieveEmployees(); 
        ArrayList<String> ids = new ArrayList<>();
        Double recordVal;
       
        for (ArrayList<String> employee : employeeList){
            recordVal = Double.parseDouble(employee.get(attribute));
            if (recordVal < minVal || recordVal > maxVal)
                ids.add(employee.get(0));
        }
        
        for (String id : ids){
            ArrayList<String> employee = getEmployeeRow(Integer.parseInt(id));
            employeeList.remove(employee);
        }
        return employeeList;
    }
    

}