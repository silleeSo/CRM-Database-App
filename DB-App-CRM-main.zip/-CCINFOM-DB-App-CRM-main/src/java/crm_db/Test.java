
package crm_db;

import java.util.*;
public class Test {
    public Address address;
    public Assignment assignment;
    public Campaign campaign;
    public CampaignMembership campaignMembership;
    public Contact contact;
    public Customer customer;
    public Employee employee;
    public Lead lead;
    public Name name;
    public OrderDetail orderDetail;
    public Orders orders;
    public Person person;
    public Product product;
    public Tags tags;
    public Tasks tasks;
    public Relation relation;
    
    public Test(){
        address = new Address();
        assignment = new Assignment();
        campaign = new Campaign();
        campaignMembership = new CampaignMembership();
        contact = new Contact();
        customer = new Customer();
        employee = new Employee();
        lead = new Lead();
        orderDetail = new OrderDetail();
        orders = new Orders();
        person = new Person();
        product = new Product();
        tags = new Tags();
        tasks = new Tasks();
        relation = new Relation();
    }
//
//    public void loadData(){
//        address.addAddress("no. 5", "Yakal", "Batasan Hills", "QC", "Manila", 1126);
//        address.addAddress("no. 5", "Yakal", "Batasan Hills", "QC", "Manila", -1126);
//        address.addAddress("no. 5", "Yakal", "Batasan Hills", "QC", "Manila", 71821);
//        address.addAddress("2", "no. 6", "Narra", "Sto Domingo", "QC", "Manila", 1000); 
//        
//        contact.addEmail("ortiz@gmail.com");
//        contact.addSocial("@imcalledchina");  
//        contact.addMobileNo(9325205892l);
//        contact.addMobileNo(5); // SHOULD NOT BE ADDED
//
////        customer.addCustomer("Chrysler", "So", "Lim", null, "F", "2023-08-11", null, null, "actually cray cray", 1, 2);
////       lead.addLead("Ma", "China", "Ortiz", null, "F", "2023-08-11", null, null, "kinda cray cray", 1, 1, "Promos", 
////          "follow up", 10, "2023-10-10", null);
//        lead.updateStatus("failed", 1);
//      
//        tags.addTag("New customer", 1);
//
//        //employee.addEmployee("So", "Chrysille", "Lim", "Direk");
//        employee.updatePosition(1, "Slay");
//        
//        
//        orders.addOrder(1, "2023-10-11", "2023-10-11", "2023-10-11", "completed", null, 10, null, -1);
//        
//
//        product.addToProduct("Scalp Massager", "This product massages the scalp.");
//        product.addToProduct("Scalp Massager", "This product massages the scalp."); // should not be added
//        product.addToProduct("Pen", "A pen");
//        
//
//        orderDetail.addOrderDetail(1, 1, 10, 3);
//        
////        assignment.addLeadAssignment(1, 1);
////        assignment.addCustomerAssignment(1, 1);
//        assignment.endAssignment(2);
//       
//        campaign.addCampaign(1, "Convert", "For conversion", "2023-11-12", null, 17000, "pending");
//        campaign.editCampaignDetail(1, "active", 2);
//        
//        campaignMembership.addCampaignMembership(1, 1);
//    
////        tasks.addTask(1, "2023-11-10", "2023-11-10", null);
////        tasks.updateStatus(1, "active");
////        tasks.updateStartDate(1, "2023-11-12");
////        tasks.updateEndDate(1, "2023-11-20");
////        
//        relation.addRelation(1, "2023-11-13", 1, 0);
//    
//    }
//

    
    public static void main(String args[]){
        // RELOAD THE CREATION SCRIPT
        Test test = new Test();
        String[] s;
        s = new String[2];
        
        s[0] = "ABC Corp";
        s[1] = "XYZ Ltd";
        
        String[] l;
        l = new String[1];
        l[0] = "in progress";
        
//        test.tasks.addTask("3", "pushed", "active", "2023-11-20", null);
//        test.orders.orderOrdersByDate(true);
//        test.orders.searchOrders("2");
//        ArrayList<Boolean> a = new ArrayList<>();
//        ArrayList<Boolean> b = new ArrayList<>();
//        a.add(true);
//        a.add(true);
//        a.add(true);
//        a.add(true);
//        a.add(true);
//        a.add(true);
//        b.add(false);
//        
//        b.add(false);
//        
//        b.add(false);
//        
//        b.add(false);
//        
//        b.add(false);
//        b.add(false);
//        
//        ArrayList<ArrayList<String>> tasks = test.orderDetail.sqlToGetGroupIndiv("SELECT CONCAT(p.lastName, ', ', p.firstName) as pName, p.sex, a.city, o.orderNumber, pr.productName, DATE_FORMAT(o.shippedDate, '%M %e, %Y') as shippedDate, ROUND(od.quantity * od.pricePerPiece, 2) as total, o.rating FROM Person p JOIN Address a ON a.addressId = p.addressId JOIN Customer c ON c.personId = p.personId JOIN Orders o ON c.customerNumber = o.customerNumber JOIN OrderDetail od ON od.orderNumber = o.orderNumber JOIN Product pr ON pr.productId = od.productId WHERE o.status = 'completed' AND productName = 'ProductA' AND YEAR(shippedDate) = '2023' AND MONTH(shippedDate) = '01' AND city = 'Cityville' AND sex = 'F'");
        
        
//        ArrayList<String> row = test.orders.getAllCustomers();
//        ArrayList<ArrayList<String>> res = test.lead.retrieveOverDueLeads();
//        
//        for(ArrayList<String > row: res) {
        ArrayList<String> row = test.customer.getStatOfCustomer(11);
            for(String r: row)

            System.out.println(r);
//        }            
//        System.out.println(test.tasks.filterById("1"));
//        System.out.println(test.assignment.getAssignmentFromPerson("Doe, John"));
        
//        test.tasks.orderTasksByEmployee(true);
//        test.customer.deleteAllTasks("11");
//        test.person.deletePerson(1, 3);
//        test.lead.deleteAllTasks("1");
//        
//        l[0] = "Referral";
        
//        test.person.getAddressId(1);
//        test.lead.qualify(null, "all", null, null, "1", "10", null, null, null, null);            
//        test.contact.deleteEmail("alice.white@example.com");
//        test.contact.deleteMobile("9876543210");
//test.contact.deleteSocial("https://linkedin.com/mary.black");
        
//        ArrayList<ArrayList<String>> a = test.lead.getPlaceholderDates();
      
//        System.out.println(a.size());
        
//        test.assignment.addCustomerAssignment(11, 3, 2);
//        test.customer.getCurrentAssignment(11);
//         test.lead.getEditableDetails(11);
            
//            test.lead.getAllEmployees();
//        test.customer.getComplaints(11);
        
//        test.customer.getAllEmployees();
//        test.loadData();  
//        test.customer.updateStatus("after sales", 0)
//        test.customer.searchCustomer("will");
//        test.employee.addEmployee("So", "Chrysille", "Lim", "Direk");
//        test.assignment.addCustomerAssignment(11, 1);
//        test.assignment.addLeadAssignment(1, 1);
//        test.customer.filterCustomersByEmployee("N/A");
//        test.customer.getAllContactOfCustomer(11);
//        test.customer.getStatOfCustomer(12);
//        test.customer.getAllContactOfCustomer(12);
//          test.customer.getFavProductByRev(12);
//          test.customer.getFavProductByQuantity(11);
//          test.customer.getOrderHistoryForCustomer(11);
//          boolean res = test.
//        System.out.println(test.customer.getPersonId(11));

//        System.out.println(test.contact.getSocial(11));
        
//        System.out.println(test.contact.getSocial1211));
//          System.out.println(res);
//        Arraytest.customer.retrievePossibleOrderNumbers();

    }
}
