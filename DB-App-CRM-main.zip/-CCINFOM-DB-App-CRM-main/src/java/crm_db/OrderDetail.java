/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */

package crm_db;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
public class OrderDetail {
    
    private IDGenerator idGenerate;
    private final String sqlInsertOrderDetail = "INSERT INTO OrderDetail VALUES (?, ?, ?, ?, ?);";
    private final String sqlFromJoined = " FROM orders o JOIN customer c ON (o.customerNumber = c.customerNumber) JOIN orderdetail od ON (od.orderNumber = o.orderNumber) JOIN person p ON (c.personId = p.personId) JOIN address a ON (p.addressId = a.addressId) JOIN product pr ON (od.productId = pr.productId) ";
    private final String sqlGetProducts = "SELECT DISTINCT productName AS dropDown" + sqlFromJoined + " WHERE o.`status` = 'completed';";
    private final String sqlGetProductsNotComplete = "SELECT DISTINCT productName AS dropDown" + sqlFromJoined;
    private final String sqlGetMonths = "SELECT DISTINCT CONCAT(YEAR(shippedDate), '-', LPAD(MONTH(shippedDate), 2, '0')) AS dropDown FROM orders o WHERE o.`status` = 'completed';"; 
    private final String sqlGetCities = "SELECT DISTINCT a.city AS dropDown " + sqlFromJoined + "WHERE o.`status` = 'completed';";
    private final String sqlGetSex = "SELECT DISTINCT p.sex AS dropDown " + sqlFromJoined + "WHERE o.`status` = 'completed';";
    private final String sqlProductId = "SELECT productId FROM product WHERE productName = ?;";
    private final String sqlRetrieveOrderDetail = "SELECT * FROM OrderDetail WHERE orderDetailId = ?;";
    private final String sqlUpdateOrderDetail = "UPDATE OrderDetail SET productId = ?, pricePerPiece = ?, quantity = ? WHERE orderdetailId = ?;";
    private final String sqlGetOrderDetailsIds = "SELECT orderdetailId FROM orderdetail od JOIN orders o ON (od.orderNumber = o.orderNumber) WHERE o.orderNumber = ?;";
  
    public OrderDetail(){
        idGenerate = new IDGenerator("orderDetailId", "OrderDetail");   
    }

    
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    
    public String addOrderDetail(int orderNumber, int productId, double pricePerPiece, int quantity){
        Connection conn = connectToDB();
        PreparedStatement insertOrderDetailStmt;
        int orderDetailId = idGenerate.getNextId();
        
        if(conn == null)
            return false;
        
        try{
            
            insertOrderDetailStmt = conn.prepareStatement(sqlInsertOrderDetail);
            insertOrderDetailStmt.setInt(1, orderDetailId);
            insertOrderDetailStmt.setInt(2, orderNumber);
            insertOrderDetailStmt.setInt(3, productId);
            insertOrderDetailStmt.setDouble(4, pricePerPiece);
            insertOrderDetailStmt.setInt(5, quantity);
            
            
            insertOrderDetailStmt.executeUpdate();
            insertOrderDetailStmt.close();
            conn.close();
            return null;
        } catch (SQLException e){
            return e.getMessage();
            // System.out.println("Exception @ orderDetail");
            // System.out.println(e);
        }
        
        return null;
    }
    public boolean updateOrderDetail(int orderDetailId, int productId, double pricePerPiece, int quantity){
        Connection conn = connectToDB();
        PreparedStatement updateOrderDetailStmt;
        
        
        if(conn == null)
            return false;
        
        try{
            
            updateOrderDetailStmt = conn.prepareStatement(sqlUpdateOrderDetail);
            updateOrderDetailStmt.setInt(1, productId);
            updateOrderDetailStmt.setDouble(2, pricePerPiece);
            updateOrderDetailStmt.setInt(3, quantity);
            updateOrderDetailStmt.setInt(4, orderDetailId);
           
            
            
            updateOrderDetailStmt.executeUpdate();
            updateOrderDetailStmt.close();
            conn.close();
            return true;
        } catch (SQLException e){
            System.out.println("Exception @ updateDetail");
            System.out.println(e);
        }
        
        return false;
    }
    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }
    public ArrayList<String> retrieveOrderDetail(int orderDetailId){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> order = new ArrayList<>();
        
    
        if (conn == null)
            return null;
    
        try {
            stmt = conn.prepareStatement(sqlRetrieveOrderDetail);
            stmt.setInt(1, orderDetailId);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                
                order.add(String.valueOf(rs.getInt("productId")));
                order.add(String.valueOf(rs.getFloat("pricePerPiece")));
                order.add(String.valueOf(rs.getInt("quantity")));
                
            }
    
            stmt.close();
            conn.close();
            return order;
            
        } catch (SQLException e) {
            System.out.println("Exception @ retrieveOrderDetail");
            System.out.println(e);
            return null;
        }
     
    }
    public ArrayList<Integer> retrieveOrderDetailIds(int orderNumber){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<Integer> orderDetailIds = new ArrayList<>();
        
    
        if (conn == null)
            return null;
    
        try {
            stmt = conn.prepareStatement(sqlGetOrderDetailsIds);
            stmt.setInt(1, orderNumber);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                orderDetailIds.add(rs.getInt("orderdetailId"));
            }
    
            stmt.close();
            conn.close();
            return orderDetailIds;
            
        } catch (SQLException e) {
            System.out.println("Exception @ retrieveOrderDetail");
            System.out.println(e);
            return null;
        }
    }
    public ArrayList<String> retrieveProducts(){
        return getDropDown(sqlGetProducts);
    }
    
    public ArrayList<String> retrieveCities(){
        return getDropDown(sqlGetCities);
    }
    
    public ArrayList<String> retrieveMonths(){
        return getDropDown(sqlGetMonths);
    }
    public ArrayList<String> retrieveSex(){
        return getDropDown(sqlGetSex);
    }
        
    public ArrayList<String> retrieveAllProducts(){
        return getDropDown(sqlGetProductsNotComplete);
    }
    public int getProductId(String productName){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        int id = -1;
    
        if (conn == null)
            return -1;
    
        try {
            stmt = conn.prepareStatement(sqlProductId);
            stmt.setString(1, productName);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                id = rs.getInt("productId");
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getProductId");
            System.out.println(e);
            return -1;
        }
        return id;
    }
    
    public String formReportSqlStmt(ArrayList<Boolean> groupings, HashMap<String, String>  filters){
        String sqlSelect = "SELECT FORMAT(SUM(od.pricePerPiece * od.quantity),2) AS revenue, FORMAT(AVG(o.rating),1) AS averageRating, COUNT(o.orderNumber) AS totalOrders";
        String sqlFrom = sqlFromJoined;
        String sqlWhere = " WHERE o.`status` = 'completed'";
        String sqlGrpBy = " GROUP BY";
        String sqlHaving = " HAVING";
        //productId, ship month-year, customer city, customer sex (M/F)
        if (groupings.get(0)){
            sqlSelect += ", pr.productName AS product";
            sqlGrpBy += " product";
        }
        if (groupings.get(1)) {
            sqlSelect += ", CONCAT(YEAR(shippedDate), '-', LPAD(MONTH(shippedDate), 2, '0')) AS shipMonth";
            if (sqlGrpBy.length() > 9) sqlGrpBy += ", ";
            sqlGrpBy += " shipMonth";
        }
        if (groupings.get(2)) {
            sqlSelect += ", a.city AS customerCity";
            if (sqlGrpBy.length() > 9) sqlGrpBy += ", ";
            sqlGrpBy += " customerCity";
        }
        if (groupings.get(3)) {
            sqlSelect += ", p.sex AS customerSex";
            if (sqlGrpBy.length() > 9) sqlGrpBy += ", ";
            sqlGrpBy += " customerSex";
        }
        //FILTERS
        if (filters.containsKey("product"))
            sqlHaving += (" pr.productName = \"" + filters.get("product")) + "\"";
        
        if (filters.containsKey("month")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" shipMonth = \"" + filters.get("month")) + "\"";
        } 
        
        if (filters.containsKey("city")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" customerCity = \"" + filters.get("city")) + "\"";
        } 
        
        if (filters.containsKey("sex")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" customerSex = \"" + filters.get("sex")) + "\"";
        } 
            
        String finalSqlStmt = sqlSelect + sqlFrom + sqlWhere;
        if (sqlGrpBy.length() > 9){
            finalSqlStmt += sqlGrpBy;
            if (sqlHaving.length() > 7) 
                finalSqlStmt += sqlHaving;
        }
        //check if there are any groupings selecting
        if (sqlSelect.length() == 142){
            finalSqlStmt = "SELECT o.orderNumber, c.customerNumber, CONCAT(p.firstName, ', ', p.lastName) AS customerName, o.rating, FORMAT(od.pricePerPiece*od.quantity,2) AS amountPaid";
            finalSqlStmt += sqlFromJoined;
            finalSqlStmt += "WHERE o.`status` = 'completed'";
            
        }
            
        finalSqlStmt += ";";
        return finalSqlStmt;
        
    }
    
    public ArrayList<ArrayList<String>> getSalesReport(ArrayList<Boolean> groupings, HashMap<String, String>  filters){
        String statement = formReportSqlStmt(groupings, filters); 
        Connection conn = connectToDB();
        PreparedStatement getSales;
        ResultSet salesRs;
        ArrayList<ArrayList<String>> salesReport = new ArrayList<>();
        // ArrayList<String> a = new ArrayList<>();
        //check if there are groupings
        boolean hasGrouping = false;
        for (boolean group: groupings)
            if(group == true)
                hasGrouping = true;
        
        if (conn == null)
            return null;

        try {
            getSales = conn.prepareStatement(statement);
            // a.add(getSales.toString());
            salesRs = getSales.executeQuery();
            //p.company, leadSource, priorityScore, conversionStatus, acqmonth, targmonth
            while (salesRs.next()){
                ArrayList<String> salesRow = new ArrayList<>();
                if (hasGrouping){
                    
                    
                    salesRow.add(String.valueOf(salesRs.getFloat("revenue")));
                    salesRow.add(String.valueOf(salesRs.getFloat("averageRating")));
                    salesRow.add(String.valueOf(salesRs.getInt("totalOrders")));
                    
                    if (groupings.get(0))
                        salesRow.add((salesRs.getString("product")));
                    if (groupings.get(1))
                        salesRow.add((salesRs.getString("shipMonth")));
                    if (groupings.get(2))
                        salesRow.add((salesRs.getString("customerCity")));
                    if (groupings.get(3))
                        salesRow.add((salesRs.getString("customerSex")));
                    
                }
                else {
                    salesRow.add(String.valueOf(salesRs.getInt("o.orderNumber")));
                    salesRow.add(String.valueOf(salesRs.getInt("c.customerNumber")));
                    salesRow.add((salesRs.getString("customerName")));
                    salesRow.add(String.valueOf(salesRs.getInt("o.rating")));
                    salesRow.add(String.valueOf(salesRs.getFloat("amountPaid")));
                    
                    
                }
                salesReport.add(salesRow);
                    
            }

            // salesReport.add(a);
            getSales.close();
            conn.close();

            return salesReport;

        } catch (SQLException e) {
            System.out.println("Exception @getLeaddsReport");
            System.out.println(e);
        }
        
    return null;
    }
    
    public ArrayList<String> getReportColumnNames(ArrayList<Boolean> groupings){
         ArrayList<String> colNames= new ArrayList<>();
        
        
        colNames.add("Generated Revenue");
        colNames.add("Average Rating");
        colNames.add("Total Orders");
        
        if (groupings.get(0))
            colNames.add("Product Name");
        if (groupings.get(1))
            colNames.add("Month-Year of Shipping");
        if (groupings.get(2))
            colNames.add("Customer City");
        if (groupings.get(3))
            colNames.add("Customer Sex (M/F)");
        
        if (colNames.size() == 3){
            colNames.clear();
            colNames.add("Order Number");
            colNames.add("Customer Number");
            colNames.add("Customer Name");
            colNames.add("Rating");
            colNames.add("Amount Paid");
            
        }
        return colNames;
    }

    public ArrayList<ArrayList<String>> sqlToGetGroupIndiv(String sql){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> indivRows = new ArrayList<>();

        if(conn == null)
            return null;

        try{
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while(rs.next()){
                ArrayList<String> rowIndiv = new ArrayList<>();

                rowIndiv.add(rs.getString("pName"));
                rowIndiv.add(rs.getString("sex"));
                rowIndiv.add(rs.getString("city"));
                rowIndiv.add(rs.getString("orderNumber"));
                rowIndiv.add(rs.getString("productName"));
                rowIndiv.add(rs.getString("shippedDate"));
                rowIndiv.add(rs.getString("total"));
                rowIndiv.add(rs.getString("rating"));

                indivRows.add(rowIndiv);
            }

            rs.close();
            conn.close();
            return indivRows;
        } catch (SQLException e){
            System.out.println("Exception @ sqlToGetGroupIndiv");
            System.out.println(e.getMessage());
        }
        return null;
    }
    public static void main (String args[]){
        OrderDetail s = new OrderDetail();
        ArrayList<Boolean> groupings = new ArrayList<>();
        HashMap<String, String> filters= new HashMap<>();
        groupings.add(false);
            groupings.add(false);
            groupings.add(false);
            groupings.add(false);
        filters.put("product", "shampoo");
        filters.put("month", "2023-05");
        
         
        System.out.println(s.getSalesReport(groupings, filters));
    }
}
