/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package crm_db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author USER
 */
public class Product {
       
    private IDGenerator idGenerate;
    private Validation validator;

    private final String sqlInsertProduct = "INSERT INTO Product VALUES (?, ?, ?);";
    
    public Product(){
        idGenerate = new IDGenerator("productId", "Product");
        validator = new Validation();
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    public boolean addToProduct(String productName, String productDetails){
        Connection conn = connectToDB();
        int nextId = idGenerate.getNextId();
        PreparedStatement insertProductStmt;

        
        productName = validator.lengthTruncate(productName, 45).toLowerCase();

        try {
            insertProductStmt = conn.prepareStatement(sqlInsertProduct);
            insertProductStmt.setInt(1, nextId);
            insertProductStmt.setString(2, productName);
            insertProductStmt.setString(3, productDetails);

            insertProductStmt.executeUpdate();

            insertProductStmt.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ addToProduct");
            System.out.println(e);
            return false;
        }

        return true;
    }


}
