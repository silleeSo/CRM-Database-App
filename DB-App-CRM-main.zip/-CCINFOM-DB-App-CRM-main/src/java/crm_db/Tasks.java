
package crm_db;
import java.sql.*;
import java.util.*;

public class Tasks {
    private final String sqlInsert =        "INSERT INTO Tasks VALUES (?, ?, ?, ?, ?, ?, ?, NULL);";
    private final String sqlUpdateStatus =  "UPDATE Tasks SET `status` = (?) WHERE taskId = (?);";
    private final String sqlUpdateStartDate =  "UPDATE Tasks SET startDate = (?) WHERE taskId = (?);";
    private final String sqlUpdateEndDate =  "UPDATE Tasks SET endDate = (?) WHERE taskId = (?);";
    private final String sqlUpdateNotes =  "UPDATE Tasks SET notes = (?) WHERE taskId = (?);";
    
    private final String sqlRetrieveTasks = "SELECT t.assignmentId, t.taskId, t.description, t.status, CONCAT(lastName, ' ', firstName) as eName, DATE_FORMAT(t.startDate, '%M %e, %Y') as startDate, IFNULL(DATE_FORMAT(t.endDate, '%M %e, %Y'), 'None') as endDate FROM Tasks t JOIN Assignment a ON a.assignmentId = t.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE t.deletedAt IS NULL ";
    private final String sqlSearchTask = sqlRetrieveTasks + " AND description LIKE ?;";
    private final String sqlFilterById = sqlRetrieveTasks + " AND taskId = ? ;";
    private final String sqlFilterByStatus = sqlRetrieveTasks + " AND t.status = ?;";
    private final String sqlFilterByEmployee = sqlRetrieveTasks + " AND  CONCAT(e.lastName, ', ', e.firstName) = ? ";
    private final String sqlOrderTasksByEmployee = sqlRetrieveTasks + " ORDER BY eName ";
    private final String sqlOrderTasksByStart = sqlRetrieveTasks + " ORDER BY t.startDate ";
    private final String sqlOrderTasksByEnd = sqlRetrieveTasks + " ORDER BY t.endDate ";
    
    private final String sqlGetAllEmployees = "SELECT CONCAT(e.lastName, ', ', e.firstName) as dropDown FROM Employee e WHERE e.deletedAt IS NULL";
    private final String sqlUpdateTask = "UPDATE Tasks SET description = ?, status = ?, startDate = ?, endDate = ? WHERE taskId = ?;";

    private final String sqlGetTask = "SELECT task as data FROM Tasks t WHERE t.taskId = ?;";
    private final String sqlGetStatus = "SELECT status as data FROM Tasks t WHERE t.taskId = ?;";
    private final String sqlGetStart = "SELECT startDate as data FROM Tasks t WHERE t.taskId = ?;";       
    private final String sqlGetEnd = "SELECT endDate as data FROM Tasks t WHERE t.taskId = ?;";
    private final String sqlGetNotes = "SELECT notes as data FROM Tasks t WHERE t.taskId = ?;";
    
    private final String sqlDelete = "UPDATE Tasks SET deletedAt = (?) WHERE taskId = (?);";

    Validation validator;
    private IDGenerator generate;
    public Tasks(){
        validator = new Validation();
        generate = new IDGenerator("taskId", "Tasks");
    }
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    //add task, update status, update start date end date edit notes
    // automatically set to pending by default, makes no sense to set to finished or active
    public int addTask(String assignmentId, String description, String status, String startDate, String endDate){
    Connection conn = connectToDB();
    PreparedStatement insertStmt;    
    int nextId = generate.getNextId();
    
    if (conn == null)
        return 0;
    
    try{
            insertStmt = conn.prepareStatement(sqlInsert);
            insertStmt.setInt(1, nextId);
            insertStmt.setString(2, description);
            insertStmt.setString(3, assignmentId);
            insertStmt.setString(4, status);
            insertStmt.setString(5, startDate);
            if(endDate != null && endDate.length() != 0)
                insertStmt.setString(6, endDate);
            else
                insertStmt.setNull(6, Types.OTHER);
            insertStmt.setString(7, validator.generateTimestamp());

            insertStmt.executeUpdate();
            insertStmt.close();
            conn.close();
            return nextId;
        }
        catch (SQLException e) {
            System.out.println("Exception @ addtask");
            System.out.println(e.getMessage());  
            return 0;
        }
    }
    
    private boolean updateStringField(int taskId, String newString, String sqlStatement){
        Connection conn = connectToDB();
        PreparedStatement updateStmt;    

        if (conn == null)
            return false;
        try{
            updateStmt = conn.prepareStatement(sqlStatement);
            updateStmt.setString(1, newString);
            updateStmt.setInt(2, taskId);
            updateStmt.executeUpdate();
            updateStmt.close();
            return true;
        }
        catch (SQLException e){
            System.out.println(e.getMessage());  
            return false;
        }
    }


    public String updateTask(String taskId, String description, String status, String startDate, String endDate){
        Connection conn = connectToDB();
        PreparedStatement stmt;    

        if (conn == null)
            return null;
        try{
            stmt = conn.prepareStatement(sqlUpdateTask);
            stmt.setString(1, description);
            stmt.setString(2, status);
            stmt.setString(3, startDate);
            if(endDate != null && endDate.length() != 0)
                stmt.setString(4, endDate);
            else
                stmt.setNull(4, Types.OTHER);
            stmt.setString(5, taskId);
            
            stmt.executeUpdate();
            // stmt.close();
            return stmt.toString();
        }
        catch (SQLException e){
            System.out.println(e.getMessage());  
            return e.getMessage();
        }
    }

    
    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }
    
    public ArrayList<String> getAllEmployees(){
        return getDropDown(sqlGetAllEmployees);
    }


    public boolean updateStatus(int taskId, String status){
        return updateStringField(taskId, status, sqlUpdateStatus);
    }
    
    public boolean updateStartDate(int taskId, String startDate){
        return updateStringField(taskId, startDate, sqlUpdateStartDate);
    }
    
    public boolean updateEndDate(int taskId, String endDate){
        return updateStringField(taskId, endDate, sqlUpdateEndDate);
    }
    
    public boolean updateNotes(int taskId, String notes){
        return updateStringField(taskId, notes, sqlUpdateNotes);
    }
    
    public boolean deleteTask(int taskId){
        return updateStringField(taskId, validator.generateTimestamp(), sqlDelete);
    }
    
    public ArrayList<ArrayList<String>> retrieveTasksFromDB(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement getTasks;
        ResultSet tasksRs;
        ArrayList<ArrayList<String>> tasks;

        
        if (conn == null)
            return null;

        try {
            getTasks = conn.prepareStatement(sqlStatement);

            tasksRs = getTasks.executeQuery();

            tasks = extractList(tasksRs);

            System.out.println(getTasks.toString());
            

            getTasks.close();
            conn.close();

            return tasks;

        } catch (SQLException e) {
            System.out.println("Exception @ retrieveTasksFromDB");
            System.out.println(e);
        }

        return null;
    }   
    
    public ArrayList<ArrayList<String>> searchTask(String string){
        Connection conn = connectToDB();
        PreparedStatement getTasks;
        ResultSet tasksRs;
        ArrayList<ArrayList<String>> tasks;
        String likeString = "%" + string + "%";

        if (conn == null)
            return null;

        try {
            getTasks = conn.prepareStatement(sqlSearchTask);

            getTasks.setString(1, likeString);
            tasksRs = getTasks.executeQuery();
            
            tasks = extractList(tasksRs);
            getTasks.close();
            conn.close();

            
            return tasks;

        } catch (SQLException e) {
            System.out.println("Exception @ searchLead");
            System.out.println(e);
        }

        return null;
    }
    
    public ArrayList<ArrayList<String>> filterTasks(String filterString, String sqlFilter) {
        Connection conn = connectToDB();
        PreparedStatement getTasksStmt;
        ResultSet tasksRs;
        ArrayList<ArrayList<String>> tasks;
    
        if (conn == null)
            return null;
    
        try {
            getTasksStmt = conn.prepareStatement(sqlFilter);
    
            getTasksStmt.setString(1, filterString);
            tasksRs = getTasksStmt.executeQuery();
    
            tasks = extractList(tasksRs);
            getTasksStmt.close();
            conn.close();
    
            return tasks;
    
        } catch (SQLException e) {
            System.out.println("Exception @ filterCustomers");
            System.out.println(e);
        }
    
        return null;
    }
    
    public ArrayList<ArrayList<String>> extractList(ResultSet tasksRs){
        ArrayList<ArrayList<String>> tasks = new ArrayList<>();
        
        try {
            while (tasksRs.next()) {
                ArrayList<String> taskRow = new ArrayList<>();

                taskRow.add(tasksRs.getString("assignmentId"));
                taskRow.add(tasksRs.getString("taskId"));
                
                taskRow.add(tasksRs.getString("description"));
                taskRow.add(tasksRs.getString("status"));
                taskRow.add(tasksRs.getString("eName"));
                taskRow.add(tasksRs.getString("startDate"));
                taskRow.add(tasksRs.getString("endDate"));


                tasks.add(taskRow);
        
                for (ArrayList<String> task : tasks) {
                    for (String taskData : task)
                        System.out.print(taskData + " ");
                    System.out.println();
                }
            }

        } catch (SQLException e) {
            System.out.println("Exception @ extractList");
            e.printStackTrace();
        }

        return tasks;
    
    }
    
    public ArrayList<ArrayList<String>> filterByStatus(String status){
        return filterTasks(status, sqlFilterByStatus);
    }
    

    public ArrayList<ArrayList<String>> filterByEmployee(String employee){
        return filterTasks(employee, sqlFilterByEmployee);
    }


    public ArrayList<ArrayList<String>> filterById(String id){
        return filterTasks(id, sqlFilterById);
    }


    public ArrayList<ArrayList<String>> orderTasksByEmployee(boolean isDescending){
        String statement = sqlOrderTasksByEmployee; 
        if(isDescending)
            statement += " DESC";
        return retrieveTasksFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderTasksByStart(boolean isDescending){
        String statement = sqlOrderTasksByStart; 
        if(isDescending)
            statement += " DESC";
        return retrieveTasksFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderTasksByEnd(boolean isDescending){
        String statement = sqlOrderTasksByEnd; 
        if(isDescending)
            statement += " DESC";
        return retrieveTasksFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> retrieveTasks(){
        return retrieveTasksFromDB(sqlOrderTasksByEmployee);
    }
    

    public String getOneCell(String sqlStatement, int id){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;

        try{
            stmt = conn.prepareStatement(sqlStatement);
            stmt.setInt(1, id);

            rs = stmt.executeQuery();

            if (rs.next()) 
                return rs.getString("data");
            
            rs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCell");
            System.out.println(e);
        }

        return null;
    }
    
    public String getTask(int taskId) {
        return getOneCell(sqlGetTask, taskId);
    }
    
    public String getStatus(int taskId) {
        return getOneCell(sqlGetStatus, taskId);
    }
    
    public String getStart(int taskId) {
        return getOneCell(sqlGetStart, taskId);
    }
    
    public String getEnd(int taskId) {
        return getOneCell(sqlGetEnd, taskId);
    }
    
    public String getNotes(int taskId) {
        return getOneCell(sqlGetNotes, taskId);
    }
}
