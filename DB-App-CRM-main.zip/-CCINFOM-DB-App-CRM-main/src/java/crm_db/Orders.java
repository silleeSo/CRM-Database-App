/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */

package crm_db;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.LinkedHashMap;

public class Orders {

    private IDGenerator idGenerate;
    private final String sqlIsValidOrder = "SELECT COUNT(*) FROM Orders WHERE orderNumber = (?) AND deletedAt is NULL;";
    private final String sqlInsertOrder = "INSERT INTO Orders VALUES (?, null, ?, ?, ?, ?, ?, ?, ?, ?, null);";
    private final String sqlInsertCustomerNumber = "UPDATE Orders SET customerNumber = (?) WHERE orderNumber = (?);";
    private final String sqlNumberOfOrders = "SELECT COUNT(*) as orderCount FROM Orders WHERE customerNumber = ? AND status != \"cancelled\";";
    private final String sqlRetrieveDetails = "SELECT od.orderNumber, o.rating, o.status, DATE_FORMAT(o.orderDate, '%M %e, %Y') as orderDate, b.total, pricePerPiece, quantity, ROUND(quantity * pricePerPiece, 2) as productTotal, p.productName, p.productDetails, CONCAT(pr.lastName, ', ', pr.firstName) as customerName FROM Orders o JOIN Orderdetail od ON o.orderNumber = od.orderNumber AND o.deletedAt IS NULL JOIN Product p ON p.productId = od.productId JOIN ( SELECT ROUND(SUM(pricePerPiece * quantity), 2) as total, od.orderNumber FROM Orderdetail od GROUP BY od.orderNumber ) b ON b.orderNumber = od.orderNumber JOIN Customer c ON c.customerNumber = o.customerNumber JOIN Person pr ON c.personId = pr.personId ";
    private final String sqlOrderByDate = sqlRetrieveDetails +  " ORDER BY o.orderDate ";
    private final String sqlOrderByAmount = sqlRetrieveDetails +  " ORDER BY b.total ";
    private final String sqlOrderByCustomer =  sqlRetrieveDetails + " ORDER BY customerName";
    private final String sqlOrderByProduct = sqlRetrieveDetails +  " ORDER BY productName ";
    private final String sqlOrderByRating = sqlRetrieveDetails +  " ORDER BY rating ";
    private final String sqlUpdateOrder = "UPDATE Orders SET  shippingAddress = ?, orderDate = ?, requiredDate = ?, shippedDate = ?, `status` = ?, complaints = ?, rating = ? WHERE orderNumber = ?;";
    private final String sqlRetrieveOrder = "SELECT * FROM orders WHERE orderNumber = ?;";
    private final String sqlGetCustomers = "SELECT customerNumber as dropDown FROM Customer c JOIN Person p on p.personId = c.personId WHERE p.deletedAt IS NULL";

    // 
    private final String sqlFilterById = sqlRetrieveDetails + " WHERE o.orderNumber = ?";
    //private final String sqlGetCustomers = "SELECT DISTINCT CONCAT(pr.lastName, ', ', pr.firstName) as dropDown FROM Orders o JOIN Orderdetail od ON o.orderNumber = od.orderNumber AND o.deletedAt IS NULL JOIN Product p ON p.productId = od.productId JOIN ( SELECT ROUND(SUM(pricePerPiece * quantity), 2) as total, od.orderNumber FROM Orderdetail od GROUP BY od.orderNumber ) b ON b.orderNumber = od.orderNumber JOIN Customer c ON c.customerNumber = o.customerNumber JOIN Person pr ON c.personId = pr.personId ";
    // customer
    private final String sqlFilterByName = sqlRetrieveDetails + " WHERE CONCAT(pr.lastName, ', ', pr.firstName) = ?";
    private final String sqlFilterByCostRange = sqlRetrieveDetails + " WHERE b.total BETWEEN ? AND ?";
    private final String sqlFilterByCostRangeStart = sqlRetrieveDetails + " WHERE b.total >= ?";

    // rating range
    private final String sqlFilterByRatingRange = sqlRetrieveDetails + " WHERE o.rating BETWEEN ? AND ?";
    private final String sqlFilterByRatingRangeStart = sqlRetrieveDetails + " WHERE o.rating >= ";

    // date range
    private final String sqlFilterByDateRange = sqlRetrieveDetails + " WHERE o.orderDate BETWEEN ? AND ?";
    private final String sqlFilterByDateRangeStart = sqlRetrieveDetails + " WHERE o.orderDate >= ";
    
    private final String sqlSearch = sqlRetrieveDetails + " WHERE o.customerNumber = ?";

    private Validation validator;

    public Orders(){
        idGenerate = new IDGenerator("orderNumber", "Orders");
        validator = new Validation();
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    

    public boolean isValidOrder(int orderNumber){
        Connection conn = connectToDB();
        PreparedStatement isValidOrderStmt;
        ResultSet isValidPersonRs;

        try{
            isValidOrderStmt = conn.prepareStatement(sqlIsValidOrder);
            
            isValidOrderStmt.setInt(1, orderNumber);

            isValidPersonRs = isValidOrderStmt.executeQuery();
 
            // actual checking
            if (!isValidPersonRs.isBeforeFirst()) {    
                System.out.println("No data"); 
                return false;
            }
            
            isValidOrderStmt.close();
            conn.close();


        } catch (SQLException e){
            System.out.println("Exception @ isValidOrder");
            System.out.println(e);
        }

        return false;
    }

    public int addOrder(int shippingAddress, String orderDate, String requiredDate, String shippedDate, 
                        String status, String complaints, int rating){
        int orderNumber = idGenerate.getNextId();
        Connection conn = connectToDB();
        PreparedStatement insertOrderStmt;

        if(conn == null)
            return -1;

        try{
            insertOrderStmt = conn.prepareStatement(sqlInsertOrder);
            insertOrderStmt.setInt(1, orderNumber);
            insertOrderStmt.setInt(2, shippingAddress);
            insertOrderStmt.setString(3, orderDate);
            insertOrderStmt.setString(4, requiredDate);
            optionalField(5, shippedDate, insertOrderStmt);
            insertOrderStmt.setString(6, status);
            optionalField(7, complaints, insertOrderStmt);
            optionalField(8, rating, insertOrderStmt);
            insertOrderStmt.setString(9, validator.generateTimestamp());

            insertOrderStmt.executeUpdate();
            insertOrderStmt.close();
            conn.close();
            

            return orderNumber;
        } catch (SQLException e){
            System.out.println("Exception @ addOrder");
            System.out.println(e);
        }

        return -1;
    }

    public int addOrder(int customerNumber, int shippingAddress, String orderDate, String requiredDate, String shippedDate, 
                        String status, String complaints, int rating){
            // check if valid customerNumber 

            int orderNumber;

            orderNumber = addOrder(shippingAddress, orderDate, requiredDate, shippedDate, status, complaints, rating);

            if(orderNumber == -1)
                return -1;
            addCustomerNumber(orderNumber, customerNumber);
            return orderNumber;

    }
    public int updateOrder(int orderNumber, int shippingAddress, String orderDate, String requiredDate, String shippedDate, 
                        String status, String complaints, int rating){
        Connection conn = connectToDB();
        PreparedStatement updateOrderStmt;

        if(conn == null)
        return -1;

        try{
            updateOrderStmt = conn.prepareStatement(sqlUpdateOrder);

            updateOrderStmt.setInt(1, shippingAddress);
            updateOrderStmt.setString(2, orderDate);
            updateOrderStmt.setString(3, requiredDate);
            optionalField(4, shippedDate, updateOrderStmt);
            updateOrderStmt.setString(5, status);
            optionalField(6, complaints, updateOrderStmt);
            optionalField(7, rating, updateOrderStmt);
            updateOrderStmt.setInt(8, orderNumber);

            updateOrderStmt.executeUpdate();
            updateOrderStmt.close();
            conn.close();


            return orderNumber;
        } catch (SQLException e){
        System.out.println("Exception @ updateOrder");
        System.out.println(e);
        }

        return -1;
    }
    public boolean addCustomerNumber(int orderNumber, int customerNumber){
        Connection conn = connectToDB();
        PreparedStatement insertCustomerNumberStmt;

        if(conn == null)  
            return false;
        
        try {

            insertCustomerNumberStmt = conn.prepareStatement(sqlInsertCustomerNumber);
            insertCustomerNumberStmt.setInt(1, customerNumber);
            insertCustomerNumberStmt.setInt(2, orderNumber);

            insertCustomerNumberStmt.executeUpdate();
            insertCustomerNumberStmt.close();
            conn.close();

            return true;
        } catch (SQLException e){
            System.out.println("Exception @ addCustomerNumber");
            System.out.println(e);
        }

        return false;   
    }
    
    private void optionalField(int paramIndex, int data, PreparedStatement stmt){
        try{

            if(data != -1)
                stmt.setInt(paramIndex, data);
            else
                stmt.setNull(paramIndex, Types.INTEGER);
           
        } catch (SQLException e) {
            System.out.println("Exception @ optionalField");
            System.out.println(e.getMessage());  
        }        
    }


    private void optionalField(int paramIndex, String data, PreparedStatement stmt){

        try{

            if(data != null)
                stmt.setString(paramIndex, data);
            else
                stmt.setNull(paramIndex, Types.OTHER);
           
        } catch (SQLException e) {
            System.out.println("Exception @ optionalField");
            System.out.println(e.getMessage());  
        }
    }    
    
    public ArrayList<ArrayList<String>> retrieveOrders(){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> allOrders = new ArrayList<>();
        
        if (conn == null)
            return null;
       
        try{
            stmt = conn.prepareStatement(sqlRetrieveDetails);

            rs = stmt.executeQuery();

            while(rs.next()){
                ArrayList<String> orderRow = new ArrayList<>();
                orderRow.add(rs.getString("orderNumber"));
                orderRow.add(rs.getString("eName"));
                orderRow.add(rs.getString("orderDate"));
                orderRow.add(rs.getString("status"));
                orderRow.add(rs.getString("rating"));
                orderRow.add(rs.getString("complaints"));
                allOrders.add(orderRow);
            }

            for(ArrayList<String> r: allOrders){
                for(String x: r){
                    System.out.println(x);
                }
            }

            return allOrders;
        
        } catch (SQLException e){
            System.out.println("Exception @ retrieveOrders");
            System.out.println(e.getMessage());
        }
        
        
        
        return null;
    }

    public ArrayList<String> retrieveOrder(int productId){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> order = new ArrayList<>();
        int id = -1;
    
        if (conn == null)
            return null;
    
        try {
            stmt = conn.prepareStatement(sqlRetrieveOrder);
            stmt.setInt(1, productId);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                
                //orderDate, requiredDate, shippedDate, status, complaints, rating, shippingAddress
                order.add(rs.getString("orderDate"));
                order.add(rs.getString("requiredDate"));
                order.add(rs.getString("shippedDate"));
                order.add(rs.getString("status"));
                order.add(rs.getString("complaints"));
                order.add(String.valueOf(rs.getInt("rating")));
                order.add(String.valueOf(rs.getInt("shippingAddress")));
                
            }
    
            stmt.close();
            conn.close();
            return order;
            
        } catch (SQLException e) {
            System.out.println("Exception @ retrieveOrder");
            System.out.println(e);
            return null;
        }
    }
    public LinkedHashMap<Integer, ArrayList<ArrayList<String>>> getOrderHistoryFromDB(String sql) {
        Connection conn = connectToDB();
        LinkedHashMap<Integer, ArrayList<ArrayList<String>>> orderHistory = new LinkedHashMap<>();
        ResultSet rs;

        try { 
            PreparedStatement stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            System.out.println(stmt.toString());

            while (rs.next()) {
                ArrayList<String> orderDetails = new ArrayList<>();
                int orderNumber = rs.getInt("orderNumber");

                orderDetails.add(rs.getString("orderNumber"));
                orderDetails.add(rs.getString("status"));
                orderDetails.add(rs.getString("orderDate"));
                orderDetails.add(rs.getString("total"));
                orderDetails.add(rs.getString("pricePerPiece"));
                orderDetails.add(rs.getString("quantity"));
                orderDetails.add(rs.getString("productTotal"));
                orderDetails.add(rs.getString("productName"));
                orderDetails.add(rs.getString("productDetails"));
                orderDetails.add(rs.getString("rating"));
                orderDetails.add(rs.getString("customerName"));

                if(orderHistory.get(orderNumber) == null)
                    orderHistory.put(orderNumber, new ArrayList<ArrayList<String>>());
                
                orderHistory.get(orderNumber).add(orderDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // for (Map.Entry<Integer, ArrayList<ArrayList<String>>> entry : orderHistory.entrySet()) {
        //     System.out.println("Order Number: " + entry.getKey());
        //     ArrayList<ArrayList<String>> orders = entry.getValue();

        //     for (ArrayList<String> order : orders) {
        //         for (String detail : order) {
        //             System.out.print(detail + "\t");
        //         }
        //         System.out.println();
        //     }
        //     System.out.println(); // Line break after each order
        // }

        return orderHistory;
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> getOrderHistory (){
        return getOrderHistoryFromDB(sqlRetrieveDetails);
    }

        
    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByDate (boolean isDescending){
        String statement = sqlOrderByDate; 
        if(isDescending)
            statement += " DESC";
        return getOrderHistoryFromDB(statement);
    }


    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByAmount(boolean isDescending) {
        String statement = sqlOrderByAmount;
        if (isDescending) {
            statement += " DESC";
        }
        return getOrderHistoryFromDB(statement);
    }
    
    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByCustomer(boolean isDescending) {
        String statement = sqlOrderByCustomer;
        if (isDescending) {
            statement += " DESC";
        }
        return getOrderHistoryFromDB(statement);
    }
    
    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByProduct(boolean isDescending) {
        String statement = sqlOrderByProduct;
        if (isDescending) {
            statement += " DESC";
        }
        return getOrderHistoryFromDB(statement);
    }
    
    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByRating(boolean isDescending) {
        String statement = sqlOrderByRating;
        if (isDescending) {
            statement += " DESC";
        }
        return getOrderHistoryFromDB(statement);
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> orderOrdersByRating() {
        return getOrderHistoryFromDB(sqlSearch);
    }

     public LinkedHashMap<Integer, ArrayList<ArrayList<String>>> filterOrders(String sql, ArrayList<String> data) {
        Connection conn = connectToDB();
        LinkedHashMap<Integer, ArrayList<ArrayList<String>>> orderHistory = new LinkedHashMap<>();
        ResultSet rs;

        try { 
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            // since the length might be custom
            int i;
            for(i = 0; i < data.size(); i++)
                stmt.setString(i+1, data.get(i));

                
            // System.out.println(stmt.toString());
            rs = stmt.executeQuery();

            while (rs.next()) {
                ArrayList<String> orderDetails = new ArrayList<>();
                int orderNumber = rs.getInt("orderNumber");

                orderDetails.add(rs.getString("orderNumber"));
                orderDetails.add(rs.getString("status"));
                orderDetails.add(rs.getString("orderDate"));
                orderDetails.add(rs.getString("total"));
                orderDetails.add(rs.getString("pricePerPiece"));
                orderDetails.add(rs.getString("quantity"));
                orderDetails.add(rs.getString("productTotal"));
                orderDetails.add(rs.getString("productName"));
                orderDetails.add(rs.getString("productDetails"));
                orderDetails.add(rs.getString("rating"));
                orderDetails.add(rs.getString("customerName"));

                if(orderHistory.get(orderNumber) == null)
                    orderHistory.put(orderNumber, new ArrayList<ArrayList<String>>());
                
                orderHistory.get(orderNumber).add(orderDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        for (Map.Entry<Integer, ArrayList<ArrayList<String>>> entry : orderHistory.entrySet()) {
            System.out.println("Order Number: " + entry.getKey());
            ArrayList<ArrayList<String>> orders = entry.getValue();

            for (ArrayList<String> order : orders) {
                for (String detail : order) {
                    System.out.print(detail + "\t");
                }
                System.out.println();
            }
            System.out.println(); // Line break after each order
        }

        return orderHistory;
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> searchOrders(String searchString){
        ArrayList<String> data = new ArrayList<>();
        data.add(searchString);
        return filterOrders(sqlFilterById, data);
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> filterByCost(String costStart, String costEnd){
        String sqlStmt = sqlFilterByCostRangeStart;
        ArrayList<String> data = new ArrayList<>();
        data.add(costStart);
        if(costEnd != null){
            data.add(costEnd);
            sqlStmt = sqlFilterByCostRange;
        }
        return filterOrders(sqlStmt, data);
    }
    
    public HashMap<Integer, ArrayList<ArrayList<String>>> filterByRating(String ratingStart, String ratingEnd){
        String sqlStmt = sqlFilterByRatingRangeStart;
        ArrayList<String> data = new ArrayList<>();
        data.add(ratingStart);
        if(ratingEnd != null){
            data.add(ratingEnd);
            sqlStmt = sqlFilterByRatingRange;
        }
        return filterOrders(sqlStmt, data);
    }
    
    public HashMap<Integer, ArrayList<ArrayList<String>>> filterByDate(String orderDateStart, String orderDateEnd){
        String sqlStmt = sqlFilterByDateRangeStart;
        ArrayList<String> data = new ArrayList<>();
        data.add(orderDateStart);
        if(orderDateEnd != null){
            data.add(orderDateEnd);
            sqlStmt = sqlFilterByDateRange;
        }
        return filterOrders(sqlStmt, data);
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> filterByCustomer(String customerName){
        ArrayList<String> data = new ArrayList<>();
        data.add(customerName);
        return filterOrders(sqlFilterByName, data);
    }

    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }

    public ArrayList<String> getAllCustomers(){
        return getDropDown(sqlGetCustomers);
    }
    
}
