/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */

package crm_db;
import java.sql.*;

public class IDGenerator {
    
    private String idFieldName;
    private String table;
    
    public IDGenerator(String idFieldName, String table){
        this.idFieldName = idFieldName;
        this.table = table;
    }
    
    public String createStatement(){
        return "SELECT IFNULL(MAX(" + idFieldName + ")+1, 1) as nextId FROM " + table;
    }
    
    public int getNextId(){
        Connection conn = connectToDB();
        PreparedStatement getIDstmt;
        ResultSet nextIdRs;
        int newId = 0;
        String sqlGetNextId = createStatement();

        if(conn == null)
            return 0;

        try{
            getIDstmt = conn.prepareStatement(sqlGetNextId);
            nextIdRs = getIDstmt.executeQuery();
     
            // guaranteed but for safety purposes
            if(nextIdRs.next())
                newId = nextIdRs.getInt(1);
            
            return newId;

        } catch (SQLException e) {
            System.out.println("Exception");
            System.out.println(e.getMessage());  
        }    

        return 0;    
    }
    
    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
}
