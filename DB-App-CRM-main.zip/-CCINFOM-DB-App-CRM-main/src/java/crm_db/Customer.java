/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package crm_db;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author USER
 */
public class Customer {
   
    private IDGenerator idGen;
    private Validation validation;
    private final String sqlInsertCustomer = "INSERT INTO Customer VALUES (?, ?, ?);";

    // dashboard deets
    private final String sqlRetrieveCustomers = "SELECT\tc.customerNumber, CONCAT(p.lastName, ', ',  p.firstName) as customerName, IFNULL(p.company, \"N/A\") AS company, c.customerStage, jc.contact, IFNULL(ROUND(a.rating, 1), '0') as rating, a.noOfComplaints, b.totalRevenue, b.quantity, IFNULL(listC.eName, \"N\\A\") AS employeeAssigned FROM Customer c JOIN Person p ON p.personID = c.personId AND p.deletedAt IS NULL JOIN ((SELECT contactId, email as contact FROM Email) UNION ALL (SELECT contactId, mobileNo as contact FROM MobileNo) UNION ALL (SELECT contactId, profileLink as contact FROM Social)) as jc ON p.contactPref = jc.contactId JOIN (SELECT customerNumber, AVG(rating) as rating, SUM(complaints IS NOT NULL) as noOfComplaints FROM Orders o GROUP BY customerNumber) a ON a.customerNumber = c.customerNumber JOIN ( SELECT ROUND(SUM(pricePerPiece * quantity), 2) as totalRevenue, SUM(quantity) as quantity, o.customerNumber FROM Orderdetail od JOIN Orders o ON od.orderNumber = o.orderNumber WHERE o.status != \"cancelled\" GROUP BY customerNumber ) b ON b.customerNumber = a.customerNumber LEFT JOIN ( SELECT c.customerNumber, IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName FROM Employee e JOIN Assignment a ON a.employeeId = e.employeeId JOIN CustomerAssignment c ON a.assignmentId = c.assignmentId WHERE a.endDate IS NULL and e.deletedAt IS NULL ) listc ON listc.customerNumber = c.customerNumber";
   
    // custom dropdown (getting employees with customer assignment only)
    private final String sqlRetrieveEmployees = "SELECT DISTINCT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS dropDown FROM Customer c JOIN Person p ON p.personID = c.personId AND p.deletedAt IS NULL LEFT JOIN CustomerAssignment ca ON ca.customerNumber = c.customerNumber LEFT JOIN Assignment a ON a.assignmentId = ca.assignmentId AND a.endDate IS NULL LEFT JOIN Employee e ON e.employeeId = a.employeeId AND e.deletedAt IS NULL;" ;
    private final String sqlRetrieveCompany = "SELECT DISTINCT p.company as dropDown FROM Customer c JOIN Person p ON p.personID = c.personId AND p.deletedAt IS NULL;";
    // get all employees with id
    private final String sqlRetrieveAllEmployees = "SELECT DISTINCT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName, e.employeeId FROM Employee e WHERE e.deletedAt IS NULL";
    
    // use for profile
    private final String sqlFilterById = sqlRetrieveCustomers + " WHERE c.customerNumber = ?;";
    private final String sqlGetComplaints = "SELECT complaints, o.orderNumber FROM OrderDetail od JOIN Orders o ON o.orderNumber = od.orderNumber WHERE customerNumber = ? AND complaints IS NOT NULL;";
    private final String sqlGetLateShipments = "SELECT orderNumber, DATE_FORMAT(requiredDate, '%M %e, %Y') as requiredDate, IFNULL(DATE_FORMAT(shippedDate, '%M %e, %Y'), 'Not yet shipped') as shippingDate FROM Orders o WHERE customerNumber = ? AND (requiredDate < shippedDate OR (requiredDate < NOW() AND shippedDate IS NULL));";
    private final String sqlUpdateStatus = "UPDATE Customer SET customerStage = ? WHERE customerNumber = ?";
    private final String sqlRetrieveEditableDetails = "SELECT p.lastName, p.firstName, IFNULL(p.middleName, 'N/A') as middleName, IFNULL(p.suffix, \"N/A\") as suffix, p.sex, p.birthdate, p.company, p.position, p.notes, a.floor, a.house_no, a.stname, a.brgy, a.city, a.province, a.zipcode, c.contactType FROM Person p JOIN Address a ON a.addressId = p.addressId JOIN Contact c ON c.contactId = p.contactPref JOIN Customer cm ON cm.personId = p.personId WHERE customerNumber = ?";
    private final String sqlGetAllCustomerContact = "SELECT jc.contact FROM Customer cm JOIN Person p ON p.personId = cm.personId JOIN Contact c ON p.personId = c.personId JOIN ((SELECT contactId, email as contact FROM Email) UNION ALL (SELECT contactId, mobileNo as contact FROM MobileNo) UNION ALL (SELECT contactId, profileLink as contact FROM Social) ) jc ON c.contactId = jc.contactId WHERE cm.customerNumber = ?;";
    private final String sqlRetrieveCustomerTotalStat = "SELECT * FROM ( SELECT ROUND(AVG(orderFrequency), 2) as stat FROM ( SELECT \tc.customerNumber, MONTH(o.orderDate), YEAR(o.orderDate),  COUNT(*) as orderFrequency FROM Customer c JOIN Orders o ON o.customerNumber = c.customerNumber GROUP BY c.customerNumber, YEAR(o.orderDate), MONTH(o.orderDate) HAVING c.customerNumber = ?) o UNION ALL (SELECT ROUND(AVG(price), 2) as averageOrderValue FROM  (SELECT \tSUM(od.pricePerPiece * od.quantity) as price FROM Customer c JOIN Orders o ON o.customerNumber = c.customerNumber JOIN Orderdetail od ON od.orderNumber = o.orderNumber WHERE c.customerNumber = ? GROUP BY o.orderNumber) orderPrices) UNION ALL (SELECT ROUND(SUM(pricePerPiece * quantity), 2) as stat FROM Orderdetail od JOIN Orders o ON od.orderNumber = o.orderNumber WHERE customerNumber = ? AND o.status != \"cancelled\" GROUP BY customerNumber) UNION ALL (SELECT SUM(quantity) as stat FROM Orderdetail od JOIN Orders o ON od.orderNumber = o.orderNumber WHERE customerNumber = ? AND o.status != \"cancelled\" GROUP BY customerNumber) ) b;";
    private final String sqlGetFavoriteProductByRevenue = "SELECT ROUND(SUM(pricePerPiece * quantity), 2) as stat, p.productName FROM Customer c JOIN Orders o ON o.customerNumber = c.customerNumber JOIN Orderdetail od ON od.orderNumber = o.orderNumber JOIN Product p ON p.productId = od.productId WHERE c.customerNumber = ? and o.status != \"cancelled\" GROUP BY od.productId, p.productName HAVING ROUND(SUM(pricePerPiece * quantity), 2) = ( SELECT ROUND(SUM(pricePerPiece * quantity), 2) as totalRevenue FROM Orderdetail WHERE orderNumber IN ( SELECT orderNumber FROM Orders WHERE customerNumber = ? AND orders.status != \"cancelled\" ) GROUP BY productId ORDER BY totalRevenue DESC LIMIT 1 );";
    private final String sqlGetFavoriteProductByQuantity = "SELECT SUM(quantity) as stat, p.productName FROM Customer c JOIN Orders o ON o.customerNumber = c.customerNumber JOIN Orderdetail od ON od.orderNumber = o.orderNumber JOIN Product p ON p.productId = od.productId WHERE c.customerNumber = ? AND o.status != \"cancelled\" GROUP BY od.productId, p.productName HAVING SUM(quantity) = ( SELECT SUM(quantity) as totalOrdered FROM Orderdetail WHERE orderNumber IN ( SELECT orderNumber FROM Orders WHERE customerNumber = ? ) GROUP BY productId ORDER BY totalOrdered DESC LIMIT 1 );";
    private final String getOrderHistory = "SELECT od.orderNumber, IFNULL(o.rating, 'Not rated yet') as rating, o.status, DATE_FORMAT(o.orderDate, '%M %e, %Y') as orderDate, b.total, pricePerPiece, quantity, ROUND(quantity * pricePerPiece, 2) as productTotal, p.productName, p.productDetails FROM Orders o JOIN Orderdetail od ON o.orderNumber = od.orderNumber JOIN Product p ON p.productId = od.productId JOIN ( SELECT ROUND(SUM(pricePerPiece * quantity), 2) as total, od.orderNumber FROM Orderdetail od GROUP BY od.orderNumber ) b ON b.orderNumber = od.orderNumber WHERE customerNumber = ? ORDER BY orderNumber;";
    private final String sqlGetAllDetails = "SELECT \tlastName, firstName, IFNULL(middleName, 'N/A') as middleName, IFNULL(suffix, \"N/A\") as suffix, sex, DATE_FORMAT(birthDate, '%M %e, %Y') as birthDate, DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(),birthDate)), '%y') as age, company, position, CONCAT(floor, ' Floor ', house_no, ', ', stname, ', ', brgy, ', ', city, ' ', zipcode) as address, p.addressId, createdAt as 'Date Added' FROM Person p JOIN Address a ON a.addressId = p.addressId WHERE personId = ?;";
    private final String sqlGetTaskHistory = "SELECT \tIFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName, t.status, t.startDate, t.endDate, t.description FROM Tasks t JOIN Assignment a ON a.assignmentId = t.assignmentId JOIN CustomerAssignment c ON c.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE c.customerNumber = ?;";
    private final String sqlGetCurrentEmployee = "SELECT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS data FROM Customer c JOIN CustomerAssignment cm ON c.customerNumber = cm.customerNumber JOIN Assignment a ON cm.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE a.endDate IS NULL AND c.customerNumber = ? AND e.deletedAt IS NULL;";
    private final String sqlGetCurrentAssignment = "SELECT a.assignmentId as data FROM Customer c JOIN CustomerAssignment cm ON c.customerNumber = cm.customerNumber JOIN Assignment a ON cm.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE a.endDate IS NULL AND c.customerNumber = ? AND e.deletedAt IS NULL;";

    // use for filtering
    private final String sqlFilterByCompany = sqlRetrieveCustomers + " WHERE p.company LIKE ?;";
    private final String sqlFilterByCustomerStage = sqlRetrieveCustomers + " WHERE c.customerStage = ?;";
    private final String sqlFilterByEmployee = sqlRetrieveCustomers + " WHERE IFNULL(listC.eName, \"None\") = ?";

    // use for ordering
    private final String sqlOrderCustomerById = sqlRetrieveCustomers + " ORDER BY c.customerNumber";
    private final String sqlOrderCustomerByLastName = sqlRetrieveCustomers + " ORDER BY p.lastName";
    private final String sqlOrderCustomerByRating = sqlRetrieveCustomers + " ORDER BY a.rating";
    private final String sqlOrderCustomerByComplaints = sqlRetrieveCustomers + " ORDER BY a.noOfComplaints";
    private final String sqlOrderCustomerByRevenue = sqlRetrieveCustomers + " ORDER BY b.totalRevenue";
    private final String sqlOrderCustomerByQuantity = sqlRetrieveCustomers + " ORDER BY b.quantity";

    // search order
    private final String sqlSearchCustomer = sqlRetrieveCustomers + " WHERE MATCH(p.firstName, p.lastName, p.middleName, p.suffix) AGAINST (?) OR p.firstName LIKE ? OR p.lastName LIKE ? OR p.middleName LIKE ? OR p.suffix LIKE ? OR p.company LIKE ?;";

    // others
    private final String getPersonId = "SELECT personId FROM Customer WHERE customerNumber = ?";
    private final String sqlGetOrderNum = "SELECT orderNumber as dropDown FROM Orders WHERE customerNumber IS NULL;";
    private String sqlGetCustomerSince = "SELECT DATE_FORMAT(MIN(orderDate), '%M %e, %Y') as data FROM Orders WHERE customerNumber = ?;";
    private final String sqlDeleteTasks = "UPDATE Tasks t JOIN Assignment a ON a.assignmentId = t.assignmentId JOIN CustomerAssignment ca ON ca.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId SET t.deletedAt = ? WHERE ca.customerNumber = ?;";

    public Customer(){
        idGen = new IDGenerator("customerNumber", "Customer");
        validation = new Validation();
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
    

    public int addCustomer( String firstName, String lastName, String middleName, String suffix, 
                                String sex, String birthDate, String company, String position, String notes, 
                                int addressId, int contactPref, String customerStage,
                                int emailId, int mobileId, int socialId){
            
        Connection conn = connectToDB();
        PreparedStatement insertNextCustomer;
        Person person = new Person();
        Contact contact = new Contact();

        int customerNumber = idGen.getNextId();
        int personId = person.addPerson("C", firstName, lastName, middleName, suffix, sex, birthDate, company, position, notes, addressId, contactPref);
        contact.addPersonToContact(emailId,  personId);
        contact.addPersonToContact(mobileId,  personId);
        contact.addPersonToContact(socialId,  personId);


        if(conn == null)
            return -1;

        try{
            insertNextCustomer = conn.prepareStatement(sqlInsertCustomer);
            
            insertNextCustomer.setInt(1, customerNumber);
            insertNextCustomer.setInt(2, personId);
            insertNextCustomer.setString(3, customerStage); 

            insertNextCustomer.executeUpdate();
            insertNextCustomer.close();
            conn.close();

            return personId;
        } catch (SQLException e){
            System.out.println("Exception @ addCustomer");
            System.out.println(e);
        }

        return -1;

    }

    private ArrayList<ArrayList<String>> extractList(ResultSet customersRs) {
        ArrayList<ArrayList<String>> customers = new ArrayList<>();

        try {
            while (customersRs.next()) {
                ArrayList<String> customerRow = new ArrayList<>();
                customerRow.add(customersRs.getString("customerNumber"));
                customerRow.add(customersRs.getString("customerName"));
                customerRow.add(customersRs.getString("company"));
                customerRow.add(customersRs.getString("customerStage"));
                customerRow.add(customersRs.getString("contact"));
                customerRow.add(customersRs.getString("rating"));
                customerRow.add(customersRs.getString("noOfComplaints"));
                customerRow.add(customersRs.getString("totalRevenue"));
                customerRow.add(customersRs.getString("quantity"));
                customerRow.add(customersRs.getString("employeeAssigned"));

                customers.add(customerRow);
            }

        } catch (SQLException e) {
            System.out.println("Exception @ extractList");
            e.printStackTrace();
        }

        for(ArrayList<String> customerRow: customers){
            for(String customerData: customerRow){
                System.out.print(customerData + " ");
            }
            System.out.println();
        }

        return customers;
    }

    public ArrayList<ArrayList<String>> retrieveCustomersFromDB(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement getCustomers;
        ResultSet customersRs;
        ArrayList<ArrayList<String>> customers = new ArrayList<>();

        if(conn == null)
            return null;

        try{

            getCustomers = conn.prepareStatement(sqlStatement);
            
            customersRs = getCustomers.executeQuery();

            customers = extractList(customersRs);

            getCustomers.close();
            conn.close();

            return customers;

        } catch (SQLException e){
            System.out.println("Exception @ retrieveCustomers");
            System.out.println(e);
        }

        return customers;
    }

    public ArrayList<ArrayList<String>> getComplaints(int customerNumber) {
        Connection conn = connectToDB();
        PreparedStatement getComplaintsStmt;
        ResultSet complaintsRs;
        ArrayList<ArrayList<String>> complaints = new ArrayList<>();
    
        if (conn == null) {
            return null;
        }
    
        try {
            getComplaintsStmt = conn.prepareStatement(sqlGetComplaints);
            getComplaintsStmt.setInt(1, customerNumber);
    
            complaintsRs = getComplaintsStmt.executeQuery();
    
            while (complaintsRs.next()) {
                System.out.println("Here");
                ArrayList<String> complaintRow = new ArrayList<>();
                
                complaintRow.add(String.valueOf(complaintsRs.getInt("orderNumber")));
                complaintRow.add(complaintsRs.getString("complaints"));
                complaints.add(complaintRow);
            }
    
            getComplaintsStmt.close();
            conn.close();
    
            return complaints;
    
        } catch (SQLException e) {
            System.out.println("Exception @ getComplaints");
            System.out.println(e);
        }


        return complaints;
    }

    public ArrayList<ArrayList<String>> getLateShipments(int customerNumber) {
        Connection conn = connectToDB();
        PreparedStatement getLateShipmentsStmt;
        ResultSet lateShipmentsRs;
        ArrayList<ArrayList<String>> lateShipments = new ArrayList<>();
    
        if (conn == null) {
            return null;
        }
    
        try {
            getLateShipmentsStmt = conn.prepareStatement(sqlGetLateShipments);
            getLateShipmentsStmt.setInt(1, customerNumber);
    
            lateShipmentsRs = getLateShipmentsStmt.executeQuery();
    
            while (lateShipmentsRs.next()) {
                ArrayList<String> shipmentDetails = new ArrayList<>();
                shipmentDetails.add(lateShipmentsRs.getString("orderNumber"));
                shipmentDetails.add(lateShipmentsRs.getString("requiredDate"));
                shipmentDetails.add(lateShipmentsRs.getString("shippingDate"));
                lateShipments.add(shipmentDetails);
            }

            for (ArrayList<String> shipment : lateShipments) {
                for (String detail : shipment) {
                    System.out.print(detail + "\t");
                }
                System.out.println();
            }
    
            getLateShipmentsStmt.close();
            conn.close();
    
            return lateShipments;
    
        } catch (SQLException e) {
            System.out.println("Exception @ getLateShipments");
            System.out.println(e);
        }
    
        return lateShipments;
    }

    public ArrayList<String> getEditableDetails(int customerNumber) {
        Connection conn = connectToDB();
        ArrayList<String> editableDetails = new ArrayList<>();
        PreparedStatement stmt;
    
        if(conn == null)
            return null;

        try {
            stmt = conn.prepareStatement(sqlRetrieveEditableDetails);
    
            stmt.setInt(1, customerNumber);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                String lastName = rs.getString("lastName");
                String firstName = rs.getString("firstName");
                String middleName = rs.getString("middleName");
                String suffix = rs.getString("suffix");
                String sex = rs.getString("sex");
                String birthDate = rs.getString("birthdate");
                String company = rs.getString("company");
                String position = rs.getString("position");
                String notes = rs.getString("notes");
                String floor = rs.getString("floor");
                String houseNumber = rs.getString("house_no");
                String streetName = rs.getString("stname");
                String barangay = rs.getString("brgy");
                String city = rs.getString("city");
                String province = rs.getString("province");
                String zipcode = rs.getString("zipcode");
                String contactType = rs.getString("contactType");
    
                // Add retrieved details to the ArrayList
                editableDetails.add(lastName);
                editableDetails.add(firstName);
                editableDetails.add(middleName);
                editableDetails.add(suffix);
                editableDetails.add(sex);
                editableDetails.add(birthDate);
                editableDetails.add(company);
                editableDetails.add(position);
                editableDetails.add(notes);
                editableDetails.add(floor);
                editableDetails.add(houseNumber);
                editableDetails.add(streetName);
                editableDetails.add(barangay);
                editableDetails.add(city);
                editableDetails.add(province);
                editableDetails.add(zipcode);
                editableDetails.add(contactType);
            }

            int i = 0;
            for (String detail : editableDetails) {
                System.out.println(i + " " + detail + "\t");
                i++;
            }

            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return editableDetails;
    }

    public ArrayList<String> getAllDetails(int personId) {
        Connection conn = connectToDB();
        ArrayList<String> getAllDetails = new ArrayList<>();
        PreparedStatement stmt;
    
        if(conn == null)
            return null;

        try {
            stmt = conn.prepareStatement(sqlGetAllDetails);
    
            stmt.setInt(1, personId);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                String lastName = rs.getString("lastName");
                String firstName = rs.getString("firstName");
                String middleName = rs.getString("middleName");
                String suffix = rs.getString("suffix");
                String age = rs.getString("age");
                String sex = rs.getString("sex");
                String birthDate = rs.getString("birthdate");
                String company = rs.getString("company");
                String position = rs.getString("position");
                String address = rs.getString("address");
                String addressId= rs.getString("addressId");
                
                getAllDetails.add(lastName);
                getAllDetails.add(firstName);
                getAllDetails.add(middleName);
                getAllDetails.add(suffix);
                getAllDetails.add(age);
                getAllDetails.add(sex);
                getAllDetails.add(birthDate);
                getAllDetails.add(company);
                getAllDetails.add(position);
                getAllDetails.add(address);
                getAllDetails.add(addressId);
            }

            int i = 0;
            for (String detail : getAllDetails) {
                System.out.println(i + " " + detail + "\t");
                i++;
            }

            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return getAllDetails;
    }
    
    

    public ArrayList<ArrayList<String>> filterCustomers(String filterString, String sqlFilter) {
        Connection conn = connectToDB();
        PreparedStatement getCustomersStmt;
        ResultSet customersRs;
        ArrayList<ArrayList<String>> customers;
    
        if (conn == null)
            return null;
    
        try {
            getCustomersStmt = conn.prepareStatement(sqlFilter);
    
            getCustomersStmt.setString(1, filterString);
            customersRs = getCustomersStmt.executeQuery();
    
            customers = extractList(customersRs);
            getCustomersStmt.close();
            conn.close();
    
            return customers;
    
        } catch (SQLException e) {
            System.out.println("Exception @ filterCustomers");
            System.out.println(e);
        }
    
        return null;
    }
    
    public boolean updateStatus(String customerStage, int customerNumber) {
        Connection conn = connectToDB();

        if (conn == null) {
            return false;
        }
        
        try{
            PreparedStatement updateStatusStmt = conn.prepareStatement(sqlUpdateStatus);
            updateStatusStmt.setString(1, customerStage);
            updateStatusStmt.setInt(2, customerNumber);
            updateStatusStmt.executeUpdate();
    
            return true;
    
        } catch (SQLException e) {
            System.out.println("Exception @ updateStatus");
            e.printStackTrace();
        }
    
        return false;
    }

    public ArrayList<ArrayList<String>> searchCustomer(String searchString) {
        Connection conn = connectToDB();
        PreparedStatement getCustomers;
        ResultSet customersRs;
        ArrayList<ArrayList<String>> customers;
        String likeString = "%" + searchString + "%";
    
        if (conn == null)
            return null;
    
        try {
            getCustomers = conn.prepareStatement(sqlSearchCustomer);
    
            getCustomers.setString(1, likeString);
            getCustomers.setString(2, likeString);
            getCustomers.setString(3, likeString);
            getCustomers.setString(4, likeString);
            getCustomers.setString(5, likeString);
            getCustomers.setString(6, likeString);
            customersRs = getCustomers.executeQuery();
    
            customers = extractList(customersRs);
            getCustomers.close();
            conn.close();
    
            return customers;
    
        } catch (SQLException e) {
            System.out.println("Exception @ searchCustomer");
            System.out.println(e);
        }
    
        return null;
    }

    public ArrayList<String> getAllContactOfCustomer(int customerNumber) {
        Connection conn = connectToDB();
        ArrayList<String> contacts = new ArrayList<>();
        ResultSet contactRs;
        PreparedStatement getAllContactStmt; 

            
        if (conn == null)
            return null;

        try {
            getAllContactStmt = conn.prepareStatement(sqlGetAllCustomerContact);

            getAllContactStmt.setInt(1, customerNumber);
            contactRs = getAllContactStmt.executeQuery();

            while (contactRs.next()) {
                String contact = contactRs.getString("contact");
                contacts.add(contact);
            }

        } catch (SQLException e) {
            System.out.println("Exception @ getAllContactOfCustomer");
            e.printStackTrace();
            return null;
        }

        for(String contact: contacts)
            System.out.println(contact);

        return contacts;
    
    }

    public ArrayList<ArrayList<String>> getTaskHistory(int customerNumber) {
        ArrayList<ArrayList<String>> taskHistory = new ArrayList<>();
        Connection conn = connectToDB();
    
        if (conn == null) {
            return null;
        }
    
        try {
            PreparedStatement stmt = conn.prepareStatement(sqlGetTaskHistory);
            stmt.setInt(1, customerNumber);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                ArrayList<String> row = new ArrayList<>();
                row.add(rs.getString("description"));
                row.add(rs.getString("status"));
                row.add(rs.getString("startDate"));
                row.add(rs.getString("endDate"));
                row.add(rs.getString("eName"));
    
                // Add row to taskHistory
                taskHistory.add(row);
            }
    
            rs.close();
            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return taskHistory;
    }
    
    

    public ArrayList<String> getStatOfCustomer(int customerId) {
        Connection conn = connectToDB();
        ArrayList<String> statistics = new ArrayList<>();
        ResultSet statsRs;
        PreparedStatement getStatStmt;

        if (conn == null)
            return null;

        try {
            getStatStmt = conn.prepareStatement(sqlRetrieveCustomerTotalStat);
            getStatStmt.setInt(1, customerId);
            getStatStmt.setInt(2, customerId);
            getStatStmt.setInt(3, customerId);
            getStatStmt.setInt(4, customerId);

            statsRs = getStatStmt.executeQuery();

            while (statsRs.next()) 
                statistics.add(statsRs.getString("stat"));

        } catch (SQLException e) {
            System.out.println("Exception @ getTotalStatOfCustomer");
            e.printStackTrace();
            return null;
        }

        for(String stat: statistics)
            System.out.println(stat);


        return statistics;
    }

    public String getCustomerSince(int id){
        return getOneCell(sqlGetCustomerSince, id);
    }

    public String getCurrentEmployee(int id){
        return getOneCell(sqlGetCurrentEmployee, id);
    }

    public String getCurrentAssignment(int id){
        return getOneCell(sqlGetCurrentAssignment, id);
    }   

    public String getOneCell(String sqlStatement, int id){
        Connection conn = connectToDB();
        PreparedStatement getContactStmt;
        ResultSet contactRs;

        try{
            getContactStmt = conn.prepareStatement(sqlStatement);
            getContactStmt.setInt(1, id);

            contactRs = getContactStmt.executeQuery();

            if (contactRs.next()) 
                return contactRs.getString("data");
            
            contactRs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCell");
            System.out.println(e);
        }

        return null;
    }


    public ArrayList<ArrayList<String>> getFavProduct(int customerNumber, String sqlStatement) {
        Connection conn = connectToDB();
        ArrayList<ArrayList<String>> favoriteProductInfo = new ArrayList<>();
        ResultSet rs;
        PreparedStatement stmt;

        if (conn == null)
            return null;

        try {
            stmt = conn.prepareStatement(sqlStatement);
            stmt.setInt(1, customerNumber);
            stmt.setInt(2, customerNumber);
            rs = stmt.executeQuery();

            while (rs.next()) {
                ArrayList<String> favProdRow = new ArrayList<>();
                String stat = rs.getString("stat");
                String productName = rs.getString("productName");

                favProdRow.add(stat);
                favProdRow.add(productName);

                favoriteProductInfo.add(favProdRow);
            }

        } catch (SQLException e) {
            System.out.println("Exception @ getRetrieveFavProductByRev");
            e.printStackTrace();
            return null;
        }

        for(ArrayList<String> prodRow: favoriteProductInfo){

            for(String data: prodRow)
                System.out.print(data + " ");
            System.out.println();
        }

        return favoriteProductInfo;
    }

    public HashMap<Integer, ArrayList<ArrayList<String>>> getOrderHistoryForCustomer(int customerNumber) {
        HashMap<Integer, ArrayList<ArrayList<String>>> orderHistory = new HashMap<>();

        try (Connection conn = connectToDB();
             PreparedStatement stmt = conn.prepareStatement(getOrderHistory)) {

            stmt.setInt(1, customerNumber);
            ResultSet rs = stmt.executeQuery();

            

            while (rs.next()) {
                ArrayList<String> orderDetails = new ArrayList<>();
                int orderNumber = rs.getInt("orderNumber");

                orderDetails.add(rs.getString("orderNumber"));
                orderDetails.add(rs.getString("status"));
                orderDetails.add(rs.getString("orderDate"));
                orderDetails.add(rs.getString("total"));
                orderDetails.add(rs.getString("pricePerPiece"));
                orderDetails.add(rs.getString("quantity"));
                orderDetails.add(rs.getString("productTotal"));
                orderDetails.add(rs.getString("productName"));
                orderDetails.add(rs.getString("productDetails"));
                orderDetails.add(rs.getString("rating"));

                if(orderHistory.get(orderNumber) == null)
                    orderHistory.put(orderNumber, new ArrayList<ArrayList<String>>());
                
                orderHistory.get(orderNumber).add(orderDetails);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (Map.Entry<Integer, ArrayList<ArrayList<String>>> entry : orderHistory.entrySet()) {
            System.out.println("Order Number: " + entry.getKey());
            ArrayList<ArrayList<String>> orders = entry.getValue();

            for (ArrayList<String> order : orders) {
                for (String detail : order) {
                    System.out.print(detail + "\t");
                }
                System.out.println();
            }
            System.out.println(); // Line break after each order
        }

        return orderHistory;
    }

    public int getPersonId(int customerNumber) {
        Connection conn = connectToDB();
        PreparedStatement getPersonIdStmt;
        ResultSet personIdRs;
    
        try {
            getPersonIdStmt = conn.prepareStatement(getPersonId);
            getPersonIdStmt.setInt(1, customerNumber);
    
            personIdRs = getPersonIdStmt.executeQuery();
    
            if (personIdRs.next()) 
                return personIdRs.getInt("personId");
    
            personIdRs.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getPersonId");
            System.out.println(e);
        }
    
        return -1;
    }
    

    public ArrayList<ArrayList<String>> getFavProductByRev(int customerNumber){
        return getFavProduct(customerNumber, sqlGetFavoriteProductByRevenue);
    }

    public ArrayList<ArrayList<String>> getFavProductByQuantity(int customerNumber){
        return getFavProduct(customerNumber, sqlGetFavoriteProductByQuantity);
    }



    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }

    public ArrayList<ArrayList<String>> getAllEmployees() {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
    
        if (conn == null)
            return employeeList;
    
        try {
            stmt = conn.prepareStatement(sqlRetrieveAllEmployees);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                ArrayList<String> employeeRow = new ArrayList<>();

                employeeRow.add(rs.getString("employeeId"));
                employeeRow.add(rs.getString("eName"));
                employeeList.add(employeeRow);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getAllEmployees");
            System.out.println(e);
        }

        for (ArrayList<String> employeeRow : employeeList) {
            for (String employeeDetail : employeeRow) {
                System.out.print(employeeDetail + " ");
            }
            System.out.println();
        }
    
        return employeeList;
    }
    

    public ArrayList<String> retrievePossibleOrderNumbers(){
        return getDropDown(sqlGetOrderNum);
    }

    public ArrayList<String> retrieveEmployeeList(){
        return getDropDown(sqlRetrieveEmployees);
    }

    public ArrayList<String> retrieveCompanyList(){
        return getDropDown(sqlRetrieveCompany);
    }
    
    
    public ArrayList<ArrayList<String>> retrieveCustomers(){
        return retrieveCustomersFromDB(sqlRetrieveCustomers);
    }

    public ArrayList<ArrayList<String>> filterCustomersByCompany(String company) {
        return filterCustomers(company, sqlFilterByCompany);
    }

    public ArrayList<ArrayList<String>> filterCustomersByEmployee(String employeeId) {
        return filterCustomers(employeeId, sqlFilterByEmployee);
    }

    public ArrayList<ArrayList<String>> filterCustomerById(String customerNumber) {
        return filterCustomers(customerNumber, sqlFilterById);
    }

    public ArrayList<ArrayList<String>> filterCustomersByStage(String stage) {
        return filterCustomers(stage, sqlFilterByCustomerStage);
    }

    public ArrayList<ArrayList<String>> orderCustomersById(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerById + " DESC" : sqlOrderCustomerById;
        return retrieveCustomersFromDB(statement);
    }

    public ArrayList<ArrayList<String>> orderCustomersByLastName(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerByLastName + " DESC" : sqlOrderCustomerByLastName;
        return retrieveCustomersFromDB(statement);
    }

    public ArrayList<ArrayList<String>> orderCustomersByRating(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerByRating + " DESC" : sqlOrderCustomerByRating;
        return retrieveCustomersFromDB(statement);
    }

    public ArrayList<ArrayList<String>> orderCustomersByComplaints(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerByComplaints + " DESC" : sqlOrderCustomerByComplaints;
        return retrieveCustomersFromDB(statement);
    }

    public ArrayList<ArrayList<String>> orderCustomersByRevenue(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerByRevenue + " DESC" : sqlOrderCustomerByRevenue;
        return retrieveCustomersFromDB(statement);
    }

    public ArrayList<ArrayList<String>> orderCustomersByQuantity(boolean isDescending) {
        String statement = isDescending ? sqlOrderCustomerByQuantity + " DESC" : sqlOrderCustomerByQuantity;
        return retrieveCustomersFromDB(statement);
    }

    public boolean deleteAllTasks(String customerNumber){

        Connection conn = connectToDB();
        PreparedStatement stmt;

        try{
            stmt = conn.prepareStatement(sqlDeleteTasks);
            

            stmt.setString(1, validation.generateTimestamp());
            stmt.setString(2, customerNumber);
 
            stmt.executeUpdate();
            
            stmt.close();
            conn.close();

            return true;

        } catch (SQLException e){
            System.out.println("Exception @ deleteAllTasks");
            System.out.println(e);
        }

        return false;
    }

}