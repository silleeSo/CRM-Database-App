/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package crm_db;
import java.sql.*;
import java.util.ArrayList;

public class Address {
    private final String sqlInsert =        "INSERT INTO Address VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
    private final String sqlUpdateFloor =  "UPDATE Address SET `floor` = (?) WHERE addressId = (?);";
    private final String sqlUpdateAddress = "UPDATE Address SET house_no = ?, stname = ?, brgy = ?, city = ?, province = ?, zipcode = ? WHERE addressId = ?;";
    private final String sqlRetrieveAddress = "SELECT * FROM Address WHERE addressId = ?;";

    Validation validator;
    private IDGenerator generate;
    public Address(){
        validator = new Validation();
        generate = new IDGenerator("addressId", "Address");
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }

    public int addAddress(String houseNo, String stName, String brgy, String city, String province, int zipcode){
        // check if 4 digits zip code tapos postive
        // call the lengthTruncate function tapos 45 length
        Connection conn = connectToDB();
        PreparedStatement insertStmt;    
        int nextId = generate.getNextId();

        if(conn == null)
            return 0;

        houseNo = validator.lengthTruncate(houseNo, 45);
        stName = validator.lengthTruncate(stName, 45);
        brgy = validator.lengthTruncate(brgy, 45);
        province = validator.lengthTruncate(province, 45);
        System.out.println("heree");
        try{
            insertStmt = conn.prepareStatement(sqlInsert);
            insertStmt.setInt(1, nextId);
            insertStmt.setNull(2, Types.INTEGER);
            insertStmt.setString(3, houseNo);
            insertStmt.setString(4, stName);
            insertStmt.setString(5, brgy);
            insertStmt.setString(6, city);
            insertStmt.setString(7, province);
            insertStmt.setInt(8, zipcode);

            insertStmt.executeUpdate();
            insertStmt.close();
            conn.close();
            return nextId;
        }
        catch (SQLException e) {
            System.out.println("Exception @ addAddress");
            System.out.println(e.getMessage());  
            return 0;
        }
    }   
    public int addAddress(String floorNo, String houseNo, String stName, String brgy, String city, String province, int zipcode){
        int addressId = addAddress(houseNo, stName, brgy, city, province, zipcode);
        if (addressId == 0)
            return 0;
        addFloor(floorNo, addressId);
        return addressId;
    }

    public boolean validateZip(int zipcode){
        return validator.zipValidation(zipcode);
    }
    //addFloor
    public String addFloor(String floorNo, int addressId){
        Connection conn = connectToDB();
        PreparedStatement insertAddressFloorStmt;


        try{
            insertAddressFloorStmt = conn.prepareStatement(sqlUpdateFloor);
            insertAddressFloorStmt.setString(1, floorNo);
            insertAddressFloorStmt.setInt(2, addressId);
            insertAddressFloorStmt.executeUpdate();
            insertAddressFloorStmt.close();
            return "done";
        }
        catch (SQLException e){
            System.out.println("Exception @ addFloor");
            System.out.println(e.getMessage());  
            return e.getMessage();
        }
        
    }

    public String updateAddress(String addressId, String houseNo, String stName, String brgy, String city, String province, int zipcode) {
        Connection conn = connectToDB();
        PreparedStatement updateStmt;

        if(conn == null)
            return null;
        
        try {
            
            
            updateStmt = conn.prepareStatement(sqlUpdateAddress);
            
            updateStmt.setString(1, houseNo);
            updateStmt.setString(2, stName);
            updateStmt.setString(3, brgy);
            updateStmt.setString(4, city);
            updateStmt.setString(5, province);
            updateStmt.setInt(6, zipcode);
            updateStmt.setString(7, addressId);
            
            updateStmt.executeUpdate();
            
            updateStmt.close();
            conn.close();
            return updateStmt.toString();
        } catch (SQLException e) {
            System.out.println("Exception @ updateAddress");
            System.out.println(e);
            return e.getMessage();
        } 
    }
    
    public ArrayList<String> retrieveAddress(int addressId){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> address = new ArrayList<>();
        
    
        if (conn == null)
            return null;
    
        try {
            stmt = conn.prepareStatement(sqlRetrieveAddress);
            stmt.setInt(1, addressId);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                
                //address, floor, house_no, stname, brgy, city, province, zipcode
                
                address.add(String.valueOf(rs.getInt("addressId")));
                address.add(rs.getString("floor"));
                address.add(rs.getString("house_no"));
                address.add(rs.getString("stname"));
                address.add(rs.getString("brgy"));
                address.add(rs.getString("city"));
                address.add(rs.getString("province"));
                address.add(String.valueOf(rs.getInt("zipcode")));
                
            }
    
            stmt.close();
            conn.close();
            return address;
            
        } catch (SQLException e) {
            System.out.println("Exception @ retrieveAddress");
            System.out.println(e);
            return null;
        }
     
    }
    
}




