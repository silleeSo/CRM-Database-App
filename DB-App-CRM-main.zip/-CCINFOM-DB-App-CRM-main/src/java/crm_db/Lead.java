/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package crm_db;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author USER
 */
public class Lead {
        
    private IDGenerator idGen;
    private Validation validation;
    private final String sqlInsertLead = "INSERT INTO Lead VALUES (?, ?, ?, ?, ?, ?, ?);";
    private final String sqlUpdateStatus = "UPDATE Lead SET conversionStatus = ? WHERE leadNumber = ?";
    private final String sqlRetrieveLeads = "SELECT l.leadNumber, CONCAT(p.lastName, ', ', p.firstName) as name, IFNULL(p.company, \"None\") AS company, l.conversionStatus, l.leadSource, l.priorityScore, DATE_FORMAT(l.leadAcquisitionDate, '%M %e, %Y') as leadAcquisitionDate, DATE_FORMAT(l.targetConversionDate,'%M %e, %Y') as targetConversionDate, jc.contact as contactPref, IFNULL(listC.eName, \"None\") AS employeeAssigned FROM Lead l JOIN Person p ON p.personID = l.personId AND p.deletedAt IS NULL JOIN ( (SELECT contactId, email as contact FROM Email) UNION ALL (SELECT contactId, mobileNo as contact FROM MobileNo) UNION ALL (SELECT contactId, profileLink as contact FROM Social) ) as jc ON p.contactPref = jc.contactId LEFT JOIN ( SELECT \tla.leadNumber, IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName FROM Employee e JOIN Assignment a ON a.employeeId = e.employeeId JOIN LeadAssignment la ON a.assignmentId = la.assignmentId WHERE a.endDate IS NULL AND e.deletedAt IS NULL ) listc ON listc.leadNumber = l.leadNumber";
    private final String sqlFilterByStatus = sqlRetrieveLeads + " WHERE l.conversionStatus = ?;";
    private final String sqlFilterByCompany = sqlRetrieveLeads + " WHERE p.company LIKE ?;";
    private final String sqlFilterByLeadSource = sqlRetrieveLeads + " WHERE l.leadSource LIKE ?;";
    private final String sqlFilterByEmployee = sqlRetrieveLeads + " WHERE IFNULL(listC.eName, \"None\") = ?";
    private final String sqlFilterById = sqlRetrieveLeads + " WHERE l.leadNumber = ?;";
    private final String sqlFilterByOverdue = sqlRetrieveLeads + " WHERE NOW() > l.targetConversionDate AND (l.conversionStatus != \"successful\" AND l.conversionStatus != \"failed\")";
    private final String sqlRetrieveAllEmployees = "SELECT DISTINCT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName, e.employeeId FROM Employee e WHERE e.deletedAt IS NULL";

    
    private final String sqlRetrieveEmployees = "SELECT DISTINCT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"None\") AS dropDown FROM Lead l JOIN Person p ON p.personId = l.personId AND p.deletedAt IS NULL  LEFT JOIN LeadAssignment la on la.leadNumber = l.leadNumber LEFT JOIN Assignment a on a.assignmentId = la.assignmentId AND a.endDate IS NULL LEFT JOIN Employee e on e.employeeId = a.employeeId AND a.endDate IS NULL";
    private final String sqlRetrieveCompany = "SELECT DISTINCT p.company as dropDown FROM Lead l JOIN Person p ON p.personID = l.personId AND p.deletedAt IS NULL;";
    private final String sqlRetrieveLeadSource = "SELECT DISTINCT l.leadSource as dropDown FROM Lead l JOIN Person p ON p.personID = l.personId AND p.deletedAt IS NULL;";
    private final String sqlRetrieveMonths = "SELECT DISTINCT CONCAT(YEAR(leadAcquisitionDate), '-', LPAD(MONTH(leadAcquisitionDate), 2, '0')) AS dropdown FROM lead;";


    private final String sqlOrderLeadById = sqlRetrieveLeads + " ORDER BY l.leadNumber";
    private final String sqlOrderLeadByLastName = sqlRetrieveLeads + " ORDER BY p.lastName";
    private final String sqlOrderLeadByPriorityScore = sqlRetrieveLeads + " ORDER BY l.priorityScore";
    private final String sqlOrderLeadByConversionStatus = sqlRetrieveLeads + " ORDER BY l.conversionStatus";
    private final String sqlOrderLeadByTargetConversionDate = sqlRetrieveLeads + " ORDER BY l.targetConversionDate";
    private final String sqlOrderLeadByLeadSource = sqlRetrieveLeads + " ORDER BY l.leadSource";
    private final String sqlOrderLeadByCompany = sqlRetrieveLeads + " ORDER BY p.company";

    private final String sqlSearchLead = sqlRetrieveLeads + " WHERE MATCH(p.firstName, p.lastName, p.middleName, p.suffix) AGAINST (?) OR p.firstName LIKE ? OR p.lastName LIKE ? OR p.middleName LIKE ? OR p.suffix LIKE ? OR p.company LIKE ?;";
    
    private final String sqlRetrieveEditableDetails = "SELECT p.lastName, p.firstName, p.middleName, IFNULL(p.suffix, \"N/A\") as suffix, p.sex, p.birthdate, p.company, p.position, p.notes, a.floor, a.house_no, a.stname, a.brgy, a.city, a.province, a.zipcode, c.contactType FROM Person p JOIN Address a ON a.addressId = p.addressId JOIN Contact c ON c.contactId = p.contactPref JOIN Lead l ON l.personId = p.personId WHERE leadNumber = ?";
    private final String sqlGetAllLeadContact = "SELECT jc.contact FROM Lead l JOIN Person p ON p.personId = l.personId JOIN Contact c ON p.personId = c.personId JOIN ((SELECT contactId, email as contact FROM Email) UNION ALL (SELECT contactId, mobileNo as contact FROM MobileNo) UNION ALL (SELECT contactId, profileLink as contact FROM Social) ) jc ON c.contactId = jc.contactId WHERE l.leadNumber = ?;";    
    private final String sqlGetAllDetails = "SELECT lastName, firstName, middleName, IFNULL(suffix, \"N/A\") as suffix, sex, DATE_FORMAT(birthDate, '%M %e, %Y') as birthDate, DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(),birthDate)), '%y') as age, company, position, CONCAT(floor, ' Floor ', house_no, ', ', stname, ', ', brgy, ', ', city, ' ', zipcode) as address, createdAt as 'Date Added' FROM Person p JOIN Address a ON a.addressId = p.addressId WHERE personId = ?;";
    private final String sqlGetTaskHistory = "SELECT \tIFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS eName, t.status, t.startDate, t.endDate, t.description FROM Tasks t JOIN Assignment a ON a.assignmentId = t.assignmentId JOIN LeadAssignment la ON la.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE la.leadNumber = ? AND t.deletedAt IS NULL;";
    private final String sqlGetCurrentEmployee = "SELECT IFNULL(CONCAT(UPPER(SUBSTRING(e.lastName, 1, 1)), LOWER(SUBSTRING(e.lastName, 2)), ', ', UPPER(SUBSTRING(e.firstName, 1, 1)), LOWER(SUBSTRING(e.firstName, 2))), \"N/A\") AS data FROM Lead l JOIN LeadAssignment la ON la.leadNumber = l.leadNumber JOIN Assignment a ON la.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE a.endDate IS NULL AND l.leadNumber = ? AND e.deletedAt IS NULL;";
    private final String sqlGetCurrentAssignment = "SELECT a.assignmentId AS data FROM Lead l JOIN LeadAssignment la ON l.leadNumber = la.leadNumber JOIN Assignment a ON la.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId WHERE a.endDate IS NULL AND l.leadNumber = ? AND e.deletedAt IS NULL;";
    private final String getPersonId = "SELECT personId FROM Lead WHERE leadNumber = ?";
    private final String placeholderDates = "( SELECT min(targetConversionDate) AS min, max(targetConversionDate) AS max FROM Lead l ) UNION ALL ( SELECT min(leadAcquisitionDate) AS min, max(leadAcquisitionDate) AS max FROM Lead l)";

    // quali
    private final String sqlBaseQualification = "SELECT leadNumber FROM Lead L JOIN Person p ON p.personId = l.personId WHERE 1 = 1 AND ";
    private final String sqlQualifyCompany = " company = ?";
    private final String sqlQualifySex = " sex = ?";
    private final String sqlQualifyLeadSource = " leadSource = ?";
    private final String sqlQualifyLeadProgress = " conversionStatus = ?";

    private final String sqlQualifyPriorityScore = " priorityScore BETWEEN ? AND ?";
    private final String sqlQualifyLeadAcquisitionDate = " leadAcquisitionDate BETWEEN ? AND ?";
    private final String sqlQualifytargetConversionDate = " targetConversionDate BETWEEN ? AND ?";
    
    private final String sqlUpdateLead = "UPDATE Lead SET leadSource = ?, priorityScore = ?, leadAcquisitionDate = ?, targetConversionDate = ? WHERE leadNumber = ?;";
    
    // delete all tasks
    private final String sqlDeleteTasks = "UPDATE Tasks t JOIN Assignment a ON a.assignmentId = t.assignmentId JOIN LeadAssignment la ON la.assignmentId = a.assignmentId JOIN Employee e ON e.employeeId = a.employeeId SET t.deletedAt = ? WHERE la.leadNumber = ?;";
    
    // additional
    private final String sqlLeadSourceInsight = "SELECT count(*) as barLength, leadSource as category FROM Lead l GROUP BY leadSource";
    private final String sqlConversionInsight = "SELECT count(*) as barLength, conversionStatus as category FROM Lead l GROUP BY conversionStatus";
    private final String sqlAcquisitionInsight = "SELECT barLength, CONCAT(m, '-', y) as category FROM ( SELECT COUNT(*) as barLength, YEAR(leadAcquisitionDate)as y , MONTH(leadAcquisitionDate) as m FROM Lead GROUP BY MONTH(leadAcquisitionDate), YEAR(leadAcquisitionDate)) B";
    private final String sqlGetOverdueLeads = "SELECT COUNT(*) as data FROM Lead l JOIN Person p ON p.personId = l.personId WHERE NOW() > targetConversionDate AND (conversionStatus != \"successful\" AND conversionStatus != \"failed\") AND deletedAt IS NULL";

    public Lead(){

        idGen = new IDGenerator("leadNumber", "Lead");
        validation = new Validation();
    }

    public String getStringQualification(String[] companies, String sex, String[] leadSources,
                                        String[] leadProgress, String priorityScoreMin, 
                                        String priorityScoremax, String acquisitionDateMin, 
                                        String acquisitionDateMax,
                                        String conversionDateMin, String conversionDateMax){
        String sqlQualification = sqlBaseQualification;
        
        if(companies != null){
            sqlQualification += " (";
            for(String company: companies)
                sqlQualification += sqlQualifyCompany + " OR ";
            sqlQualification += " 1 = 0 ) AND ";
        }   

        
        if(sex != null && !sex.equalsIgnoreCase("all")){
            sqlQualification += " (" + sqlQualifySex + ") AND";
        }

        if(leadSources != null){
            sqlQualification += " (";
            for(String leadSource: leadSources)
                sqlQualification += sqlQualifyLeadSource + " OR ";
            sqlQualification += " 1 = 0 ) AND ";
        }   

        
        if(leadProgress != null){
            sqlQualification += " (";
            for(String progress: leadProgress)
                sqlQualification += sqlQualifyLeadProgress + " OR ";
            sqlQualification += " 1 = 0 ) AND ";
        }   

        sqlQualification += " (" + sqlQualifyPriorityScore + ") AND";
        

        sqlQualification += " (" + sqlQualifyLeadAcquisitionDate + ") AND";


        sqlQualification += " (" + sqlQualifytargetConversionDate;
        
        if(conversionDateMax.length() == 0 && conversionDateMin.length() == 0);
            sqlQualification += " OR targetConversionDate IS NULL";
    
        sqlQualification += ") ORDER BY priorityScore DESC";

        System.out.println(sqlQualification);
        return sqlQualification;
    }

    public String updateLead(String leadSource, String leadAcquisionDate, String priorityScore, 
                            String targetConversionDate, String leadNumber) {
        Connection conn = connectToDB();
        PreparedStatement pstmt;

        try {

        pstmt = conn.prepareStatement(sqlUpdateLead);

        pstmt.setString(1, leadSource);
        pstmt.setString(2, priorityScore);
        pstmt.setString(3, leadAcquisionDate);
        optionalField(4, targetConversionDate, pstmt); 
        pstmt.setString(5, leadNumber); 

        pstmt.executeUpdate();

        return pstmt.toString();
        } catch (SQLException e) {
        e.printStackTrace(); // Handle or log the exception as needed
        return e.getMessage();
    }    
    }


    public ArrayList<String> qualify(   String[] companies, String sex, 
                                        String[] leadSources, String[] leadProgress,
                                        String priorityScoreMin, String priorityScoremax, 
                                        String acquisitionDateMin, String acquisitionDateMax,
                                        String conversionDateMin, String conversionDateMax){
        String sqlQualification = getStringQualification(   companies, sex, leadSources,
                                                            leadProgress, priorityScoreMin, 
                                                            priorityScoremax, acquisitionDateMin, acquisitionDateMax, 
                                                            conversionDateMin, conversionDateMax);
        

        Connection conn = connectToDB();
        PreparedStatement stmt;
        ArrayList<String> qualifiedLeads = new ArrayList<>();
        ArrayList<ArrayList<String>> dates = getPlaceholderDates();
        ResultSet leadsRs;

        if(conn == null)
            return null;

        if(conversionDateMin.length() == 0)
            conversionDateMin = dates.get(0).get(0);
            
        if(conversionDateMax.length() == 0)
            conversionDateMax = dates.get(0).get(1);
            
        if(acquisitionDateMin.length() == 0)
            acquisitionDateMin = dates.get(1).get(0);
            
        if(acquisitionDateMax.length() == 0)
            acquisitionDateMax = dates.get(1).get(1);

        try{


            stmt = conn.prepareStatement(sqlQualification);

            int i = 1;
            if(companies != null){
                for(String company: companies){

                    stmt.setString(i, company);
                    i++;
                }
            }

            if(sex != null && !sex.equalsIgnoreCase("all")){
                stmt.setString(i, sex);
                i++;
            }

            if(leadSources != null){
                for(String source: leadSources){

                    stmt.setString(i, source);
                    i++;
                }
            }
            
            if(leadProgress != null){
                for(String progress: leadProgress){

                    stmt.setString(i, progress);
                    i++;
                }
            }

            stmt.setString(i++, priorityScoreMin);
            stmt.setString(i++, priorityScoremax);
            stmt.setString(i++, acquisitionDateMin);
            stmt.setString(i++, acquisitionDateMax);
            stmt.setString(i++, conversionDateMin);
            stmt.setString(i++, conversionDateMax);

            leadsRs = stmt.executeQuery();
            // System.out.println(preparedStatement);

            while(leadsRs.next()){
                qualifiedLeads.add(leadsRs.getString("leadNumber"));
            }

            qualifiedLeads.add(stmt.toString());

            for(String leads: qualifiedLeads)
                System.out.println(leads);
            return qualifiedLeads;
        } catch (SQLException e){
            System.out.println("exception @ qualify");
            System.out.println(e.getMessage());
        }

        
        return null;
    }

    public ArrayList<ArrayList<String>> getPlaceholderDates(){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ArrayList<ArrayList<String>> dates = new ArrayList<>();
        ResultSet datesRs;

        if(conn == null)
            return null;
        
        try{
            stmt = conn.prepareStatement(placeholderDates);
            datesRs = stmt.executeQuery();

            while(datesRs.next()){
                ArrayList<String> dateRow = new ArrayList<>();

                dateRow.add(datesRs.getString("min"));
                dateRow.add(datesRs.getString("max"));
            
                dates.add(dateRow);
            }


            datesRs.close();
            conn.close();

            
            return dates;
        } catch (SQLException e){
            System.out.println("Exception @ getPlaceholderDates");
            System.out.println(e.getMessage());
            
        }

        return null;
        
    }

    private Connection connectToDB(){
        // 1. Instantiate a connection variable
        Connection conn;     

        try {
            Class.forName("com.mysql.jdbc.Driver");  
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crm_db","root","12345");  
            System.out.println("Connection Successful");
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());  
            return null;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }    
        return conn;
    }
        
    private void optionalField(int paramIndex, String data, PreparedStatement stmt){
        try{

            if(data != null && data.length() != 0)
                stmt.setString(paramIndex, data);
            else
                stmt.setNull(paramIndex, Types.OTHER);
           
        } catch (SQLException e) {
            System.out.println("Exception @ optionalField");
            System.out.println(e.getMessage());  
        }
    }    

    public boolean addLeadToDb(int personId, String leadSource, String conversionStatus, int priorityScore, String leadAcquisitionDate, String targetConversionDate){

        Connection conn = connectToDB();
        PreparedStatement insertLeadStmt;
        int leadNumber = idGen.getNextId();


  
        try{
            insertLeadStmt = conn.prepareStatement(sqlInsertLead);
            insertLeadStmt.setInt(1, leadNumber);
            insertLeadStmt.setInt(2, personId);
            insertLeadStmt.setString(3, leadSource);
            insertLeadStmt.setString(4, conversionStatus);
            insertLeadStmt.setInt(5, priorityScore);
            insertLeadStmt.setString(6, leadAcquisitionDate);
            
            optionalField(7, targetConversionDate, insertLeadStmt);

            insertLeadStmt.executeUpdate();
            
            insertLeadStmt.close();
            conn.close();

            return true;

        } catch (SQLException e){
            System.out.println("Exception @ addLeadToDb");
            System.out.println(e);
        }



        return false;
    }

    public boolean deleteAllTasks(String leadNumber){

        Connection conn = connectToDB();
        PreparedStatement stmt;

        try{
            stmt = conn.prepareStatement(sqlDeleteTasks);
            stmt.setString(1, validation.generateTimestamp());
            stmt.setString(2, leadNumber);
 
            stmt.executeUpdate();
            
            stmt.close();
            conn.close();

            return true;

        } catch (SQLException e){
            System.out.println("Exception @ deleteAllTasks");
            System.out.println(e);
        }

        return false;
    }
    
    public boolean addLead( String firstName, String lastName, String middleName, String suffix, 
                            String sex, String birthDate, String company, String position, String notes, 
                            int addressId, int contactPref, String leadSource, String conversionStatus, 
                            int priorityScore, String leadAcquisitionDate, String targetConversionDate,
                            int emailId, int mobileId, int socialId){
        
        Person person = new Person();
        Contact contact = new Contact();
        int personId = person.addPerson("L", firstName, lastName, middleName, suffix, sex, birthDate, company, position, notes, addressId, contactPref);
        contact.addPersonToContact(emailId,  personId);
        contact.addPersonToContact(mobileId,  personId);
        contact.addPersonToContact(socialId,  personId);

        if(personId == -1)
            return false;
        
       return addLeadToDb(personId, leadSource, conversionStatus, priorityScore, leadAcquisitionDate, targetConversionDate);
    }

    public String getCurrentEmployee(int id){
        return getOneCell(sqlGetCurrentEmployee, id);
    }

    public String getCurrentAssignment(int id){
        return getOneCell(sqlGetCurrentAssignment, id);
    }   


    
    public ArrayList<ArrayList<String>> getAllEmployees() {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> employeeList = new ArrayList<>();
    
        if (conn == null)
            return employeeList;
    
        try {
            stmt = conn.prepareStatement(sqlRetrieveAllEmployees);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                ArrayList<String> employeeRow = new ArrayList<>();

                employeeRow.add(rs.getString("employeeId"));
                employeeRow.add(rs.getString("eName"));
                employeeList.add(employeeRow);
                System.out.println("has rs");
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getAllEmployees");
            System.out.println(e);
        }

        for (ArrayList<String> employeeRow : employeeList) {
            for (String employeeDetail : employeeRow) {
                System.out.print(employeeDetail + " ");
            }
            System.out.println();
        }
    
        return employeeList;
    }

    public String getOneCell(String sqlStatement, int id){
        Connection conn = connectToDB();
        PreparedStatement getContactStmt;
        ResultSet contactRs;

        try{
            getContactStmt = conn.prepareStatement(sqlStatement);
            getContactStmt.setInt(1, id);

            contactRs = getContactStmt.executeQuery();

            if (contactRs.next()) 
                return contactRs.getString("data");
            
            contactRs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOneCell");
            System.out.println(e);
        }

        return null;
    }

    public String getOverdueLeads(){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;

        try{
            stmt = conn.prepareStatement(sqlGetOverdueLeads);

            rs = stmt.executeQuery();

            if (rs.next()) 
                return rs.getString("data");
            
            rs.close();
            conn.close();
        } catch (SQLException e){
            System.out.println("Exception @ getOverdueLeads");
            System.out.println(e);
        }

        return null;
    }

    public int getPersonId(int leadNumber) {
        Connection conn = connectToDB();
        PreparedStatement getPersonIdStmt;
        ResultSet personIdRs;
    
        try {
            getPersonIdStmt = conn.prepareStatement(getPersonId);
            getPersonIdStmt.setInt(1, leadNumber);
    
            personIdRs = getPersonIdStmt.executeQuery();
    
            if (personIdRs.next()) 
                return personIdRs.getInt("personId");
    
            personIdRs.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getPersonId");
            System.out.println(e);
        }
    
        return -1;
    }

    public ArrayList<ArrayList<String>> getTaskHistory(int leadNumber) {
        ArrayList<ArrayList<String>> taskHistory = new ArrayList<>();
        Connection conn = connectToDB();
    
        if (conn == null) {
            return null;
        }
    
        try {
            PreparedStatement stmt = conn.prepareStatement(sqlGetTaskHistory);
            stmt.setInt(1, leadNumber);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                ArrayList<String> row = new ArrayList<>();
                
                row.add(rs.getString("description"));
                row.add(rs.getString("status"));
                row.add(rs.getString("startDate"));
                row.add(rs.getString("endDate"));
                row.add(rs.getString("eName"));

                taskHistory.add(row);
            }
    
            rs.close();
            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return taskHistory;
    }


    public ArrayList<String> getAllDetails(int personId) {
        Connection conn = connectToDB();
        ArrayList<String> getAllDetails = new ArrayList<>();
        PreparedStatement stmt;
    
        if(conn == null)
            return null;

        try {
            stmt = conn.prepareStatement(sqlGetAllDetails);
    
            stmt.setInt(1, personId);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                String lastName = rs.getString("lastName");
                String firstName = rs.getString("firstName");
                String middleName = rs.getString("middleName");
                String suffix = rs.getString("suffix");
                String age = rs.getString("age");
                String sex = rs.getString("sex");
                String birthDate = rs.getString("birthdate");
                String company = rs.getString("company");
                String position = rs.getString("position");
                String address = rs.getString("address");
                
                getAllDetails.add(lastName);
                getAllDetails.add(firstName);
                getAllDetails.add(middleName);
                getAllDetails.add(suffix);
                getAllDetails.add(age);
                getAllDetails.add(sex);
                getAllDetails.add(birthDate);
                getAllDetails.add(company);
                getAllDetails.add(position);
                getAllDetails.add(address);
            }

            int i = 0;
            for (String detail : getAllDetails) {
                System.out.println(i + " " + detail + "\t");
                i++;
            }

            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return getAllDetails;
    }

    public ArrayList<String> getAllContactOfLead(int leadNumber) {
        Connection conn = connectToDB();
        ArrayList<String> contacts = new ArrayList<>();
        ResultSet contactRs;
        PreparedStatement getAllContactStmt; 

            
        if (conn == null)
            return null;

        try {
            getAllContactStmt = conn.prepareStatement(sqlGetAllLeadContact);

            getAllContactStmt.setInt(1, leadNumber);
            contactRs = getAllContactStmt.executeQuery();

            while (contactRs.next()) {
                String contact = contactRs.getString("contact");
                contacts.add(contact);
            }

        } catch (SQLException e) {
            System.out.println("Exception @ getAllContactOfLead");
            e.printStackTrace();
            return null;
        }

        for(String contact: contacts)
            System.out.println(contact);

        return contacts;
    
    }

    public ArrayList<String> getEditableDetails(int leadNumber) {
        Connection conn = connectToDB();
        ArrayList<String> editableDetails = new ArrayList<>();
        PreparedStatement stmt;
    
        if(conn == null)
            return null;

        try {
            stmt = conn.prepareStatement(sqlRetrieveEditableDetails);
    
            stmt.setInt(1, leadNumber);
            ResultSet rs = stmt.executeQuery();
    
            while (rs.next()) {
                String lastName = rs.getString("lastName");
                String firstName = rs.getString("firstName");
                String middleName = rs.getString("middleName");
                String suffix = rs.getString("suffix");
                String sex = rs.getString("sex");
                String birthDate = rs.getString("birthdate");
                String company = rs.getString("company");
                String position = rs.getString("position");
                String notes = rs.getString("notes");
                String floor = rs.getString("floor");
                String houseNumber = rs.getString("house_no");
                String streetName = rs.getString("stname");
                String barangay = rs.getString("brgy");
                String city = rs.getString("city");
                String province = rs.getString("province");
                String zipcode = rs.getString("zipcode");
                String contactType = rs.getString("contactType");
    
                editableDetails.add(lastName);
                editableDetails.add(firstName);
                editableDetails.add(middleName);
                editableDetails.add(suffix);
                editableDetails.add(sex);
                editableDetails.add(birthDate);
                editableDetails.add(company);
                editableDetails.add(position);
                editableDetails.add(notes);
                editableDetails.add(floor);
                editableDetails.add(houseNumber);
                editableDetails.add(streetName);
                editableDetails.add(barangay);
                editableDetails.add(city);
                editableDetails.add(province);
                editableDetails.add(zipcode);
                editableDetails.add(contactType);
            }

            int i = 0;
            for (String detail : editableDetails) {
                System.out.println(i + " " + detail + "\t");
                i++;
            }

            stmt.close();
            conn.close();
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return editableDetails;
    }

    public boolean updateStatus(String conversionStatus, int leadNumber){
        Connection conn = connectToDB();
        PreparedStatement updateStatusStmt;
        
        if(conn == null)
            return false;

        try{
            updateStatusStmt = conn.prepareStatement(sqlUpdateStatus);
            updateStatusStmt.setString(1, conversionStatus);
            updateStatusStmt.setInt(2, leadNumber);
            updateStatusStmt.executeUpdate();

            updateStatusStmt.close();
            conn.close();
            return true;

        } catch (SQLException e){
            System.out.println("Exception @ updateStatus");
            System.out.println(e);
        }

        return false;
    }

    public ArrayList<ArrayList<String>> extractList(ResultSet leadsRs){
        ArrayList<ArrayList<String>> leads = new ArrayList<>();
        
        try {
            while (leadsRs.next()) {
                ArrayList<String> leadRow = new ArrayList<>();
                leadRow.add(leadsRs.getString("leadNumber"));
                leadRow.add(leadsRs.getString("name"));
                leadRow.add(leadsRs.getString("company"));
                leadRow.add(leadsRs.getString("leadSource"));
                leadRow.add(leadsRs.getString("priorityScore"));
                leadRow.add(leadsRs.getString("conversionStatus"));
                leadRow.add(leadsRs.getString("leadAcquisitionDate"));
                leadRow.add(leadsRs.getString("targetConversionDate"));
                leadRow.add(leadsRs.getString("contactPref"));
                leadRow.add(leadsRs.getString("employeeAssigned"));

                leads.add(leadRow);
        
                for (ArrayList<String> lead : leads) {
                    for (String leadData : lead)
                        System.out.print(leadData + " ");
                    System.out.println();
                }
            }

        } catch (SQLException e) {
            System.out.println("Exception @ extractList");
            e.printStackTrace();
        }

        return leads;
    
    }

    public ArrayList<ArrayList<String>> retrieveLeadsFromDB(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement getLeads;
        ResultSet leadsRs;
        ArrayList<ArrayList<String>> leads;

        
        if (conn == null)
            return null;

        try {
            getLeads = conn.prepareStatement(sqlStatement);

            leadsRs = getLeads.executeQuery();

            leads = extractList(leadsRs);


            getLeads.close();
            conn.close();

            return leads;

        } catch (SQLException e) {
            System.out.println("Exception @ retrieveLeads");
            System.out.println(e);
        }

        return null;
    }   

    public ArrayList<ArrayList<String>> searchLead(String string){
        Connection conn = connectToDB();
        PreparedStatement getLeads;
        ResultSet leadsRs;
        ArrayList<ArrayList<String>> leads;
        String likeString = "%" + string + "%";

        if (conn == null)
            return null;

        try {
            getLeads = conn.prepareStatement(sqlSearchLead);

            getLeads.setString(1, string);
            getLeads.setString(2, likeString);
            getLeads.setString(3, likeString);
            getLeads.setString(4, likeString);
            getLeads.setString(5, likeString);
            getLeads.setString(6, likeString);
            leadsRs = getLeads.executeQuery();
            
            leads = extractList(leadsRs);
            getLeads.close();
            conn.close();

            
            return leads;

        } catch (SQLException e) {
            System.out.println("Exception @ searchLead");
            System.out.println(e);
        }

        return null;
    }

    public ArrayList<ArrayList<String>> filterLeads(String filterString, String sqlFilter){
        Connection conn = connectToDB();
        PreparedStatement getLeadsStmt;
        ResultSet leadsRs;
        ArrayList<ArrayList<String>> leads;


        if (conn == null)
            return null;

        try {
            getLeadsStmt = conn.prepareStatement(sqlFilter);

            getLeadsStmt.setString(1, filterString);
            leadsRs = getLeadsStmt.executeQuery();
            
            leads = extractList(leadsRs);
            getLeadsStmt.close();
            conn.close();

            
            return leads;

        } catch (SQLException e) {
            System.out.println("Exception @ filterLeads");
            System.out.println(e);
        }

        return null;
    }

    public ArrayList<String> getDropDown(String sqlStatement) {
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<String> dropdown = new ArrayList<>();
    
        if (conn == null)
            return dropdown;
    
        try {
            stmt = conn.prepareStatement(sqlStatement);
            rs = stmt.executeQuery();
    
            while (rs.next()) {
                String selection = rs.getString("dropDown");
                dropdown.add(selection);
            }
    
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Exception @ getDropDown");
            System.out.println(e);
        }
    
        return dropdown;
    }
    
    public ArrayList<String> retrieveLeadSource(){
        return getDropDown(sqlRetrieveLeadSource);
    }

    public ArrayList<String> retrieveEmployee(){
        return getDropDown(sqlRetrieveEmployees);
    }

    public ArrayList<String> retrieveCompanyList(){
        return getDropDown(sqlRetrieveCompany);
    }
    
    public ArrayList<ArrayList<String>> filterLeadsById(String leadNumber) {
        return filterLeads(leadNumber, sqlFilterById);
    }

    public ArrayList<ArrayList<String>> filterByStatus(String status){
        return filterLeads(status, sqlFilterByStatus);
    }

    
    public ArrayList<ArrayList<String>> filterByLeadSource(String status){
        return filterLeads(status, sqlFilterByLeadSource);
    }


    public ArrayList<ArrayList<String>> filterByCompany(String status){
        return filterLeads(status, sqlFilterByCompany);
    }

    
    public ArrayList<ArrayList<String>> filterByEmployee(String employee){
        return filterLeads(employee, sqlFilterByEmployee);
    }


    public ArrayList<ArrayList<String>> retrieveLeads(){
        return retrieveLeadsFromDB(sqlOrderLeadById + " DESC");
    }

    
    public ArrayList<ArrayList<String>> retrieveOverDueLeads(){
        return retrieveLeadsFromDB(sqlFilterByOverdue);
    }

    public ArrayList<ArrayList<String>> orderLeadsByLastName(boolean isDescending){
        String statement = sqlOrderLeadByLastName; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderLeadsByPriorityScore(boolean isDescending){
        String statement = sqlOrderLeadByPriorityScore; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderLeadsByConversionStatus(boolean isDescending){
        String statement = sqlOrderLeadByConversionStatus; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderLeadsByTargetConversionDate(boolean isDescending){
        String statement = sqlOrderLeadByTargetConversionDate; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderLeadsByLeadSource(boolean isDescending){
        String statement = sqlOrderLeadByLeadSource; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<ArrayList<String>> orderLeadsByCompany(boolean isDescending){
        String statement = sqlOrderLeadByCompany; 
        if(isDescending)
            statement += " DESC";
        return retrieveLeadsFromDB(statement);
    }
    
    public ArrayList<String> retrieveMonthsList(){
        return getDropDown(sqlRetrieveMonths);
    }
    
    public String formReportSqlStmt(ArrayList<Boolean> groupings, HashMap<String, String>  filters){
        //p.company, leadSource, priorityScore, conversionStatus, acqmonth, targmonth
       
        String sqlSelect = "SELECT AVG(l.priorityScore), SUM(CASE WHEN NOW() > l.targetConversionDate AND l.conversionStatus = 'in progress' THEN 1 ELSE 0 END) AS overdueLeads, FORMAT(SUM(l.conversionStatus = 'successful')/COUNT(l.leadNumber)*100,2) AS successRate, COUNT(l.leadNumber) AS totalLeads";
        String sqlFrom = " FROM lead l";
        String sqlGrpBy = " GROUP BY ";
        String sqlHaving = " HAVING";
        
        //select and groupby
        if (groupings.get(0)) {
            sqlSelect += ", IFNULL(p.company, \"None\") AS company";
            sqlGrpBy += " p.company";
            sqlFrom += " JOIN person p ON (l.personId = p.personId)";
        }
        if (groupings.get(1)) {
            sqlSelect += ", l.leadSource";
            if (sqlGrpBy.length() > 10) sqlGrpBy += ", ";
            sqlGrpBy += " l.leadSource";
        }
            
        if (groupings.get(2)){
            sqlSelect += ", l.priorityScore";
            if (sqlGrpBy.length() > 10) sqlGrpBy += ", ";
            sqlGrpBy += " l.priorityScore";
        }
            
        if (groupings.get(3)){
            sqlSelect += ", l.conversionStatus";
            if (sqlGrpBy.length() > 10) sqlGrpBy += ", ";
            sqlGrpBy += " l.conversionStatus";
           
        }
            
        if (groupings.get(4)){
            sqlSelect += ", CONCAT(YEAR(leadAcquisitionDate), '-', LPAD(MONTH(leadAcquisitionDate), 2, '0')) AS acqMonth";
            if (sqlGrpBy.length() > 10) sqlGrpBy += ", ";
            sqlGrpBy += " acqMonth";
        }
            
        if (groupings.get(5)){
            sqlSelect += ", CONCAT(YEAR(targetConversionDate), '-', LPAD(MONTH(targetConversionDate), 2, '0')) AS targMonth";
            if (sqlGrpBy.length() > 10) sqlGrpBy += ", ";
            sqlGrpBy += " targMonth";
        }
            
        
        
        //filters
        //check if key exists
        if (filters.containsKey("company"))
            sqlHaving += (" p.company = \"" + filters.get("company")) + "\"";
        if (filters.containsKey("status")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" conversionStatus = \"" + filters.get("status")) + "\"";
        } 
        if (filters.containsKey("source")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" leadSource = \"" + filters.get("source")) + "\"";
        } 
        if (filters.containsKey("month")){
            if (sqlHaving.length() > 7) sqlHaving += " AND ";
            sqlHaving += (" acqMonth = \"" + filters.get("month")) + "\"";
        } 
        
        String finalSqlStmt = sqlSelect + sqlFrom;
        if (sqlGrpBy.length() > 10){
            finalSqlStmt += sqlGrpBy;
            if (sqlHaving.length() > 7) 
                finalSqlStmt += sqlHaving;
        }
        if (sqlSelect.length() == 271)
            finalSqlStmt = "SELECT l.*, p.company FROM lead l JOIN person p ON (l.personId = p.personId)";
        finalSqlStmt += ";";
        
        System.out.println(finalSqlStmt);
        System.out.println(sqlGrpBy);
        System.out.println(sqlHaving);
        return finalSqlStmt;
    }

    public ArrayList<ArrayList<String>> getLeadsReport(ArrayList<Boolean> groupings, HashMap<String, String>  filters){
        String statement = formReportSqlStmt(groupings, filters); 
        Connection conn = connectToDB();
        PreparedStatement getLeads;
        ResultSet leadsRs;
        ArrayList<ArrayList<String>> leadReport = new ArrayList<>();
        //check if there are groupings
        boolean hasGrouping = false;
        for (boolean group: groupings)
            if(group == true)
                hasGrouping = true;
        
        if (conn == null)
            return null;

        try {
            getLeads = conn.prepareStatement(statement);
            leadsRs = getLeads.executeQuery();
            //p.company, leadSource, priorityScore, conversionStatus, acqmonth, targmonth
            while (leadsRs.next()){
                ArrayList<String> leadRow = new ArrayList<>();
                if (hasGrouping){
                    
                    leadRow.add(String.valueOf(leadsRs.getFloat("AVG(l.priorityScore)")));
                    leadRow.add(String.valueOf(leadsRs.getInt("overdueLeads")));
                    leadRow.add(String.valueOf(leadsRs.getFloat("successRate")));
                    leadRow.add(String.valueOf(leadsRs.getInt("totalLeads")));
                    if (groupings.get(0))
                        leadRow.add((leadsRs.getString("company")));
                    if (groupings.get(1))
                        leadRow.add((leadsRs.getString("leadSource")));
                    if (groupings.get(2))
                        leadRow.add((leadsRs.getString("priorityScore")));
                    if (groupings.get(3))
                        leadRow.add((leadsRs.getString("conversionStatus")));
                    //ADD DATES
                    if (groupings.get(4))
                        leadRow.add((leadsRs.getString("acqMonth")));
                    if (groupings.get(5))
                        leadRow.add((leadsRs.getString("targMonth")));
                }
                else {
                    leadRow.add((leadsRs.getString("leadNumber")));
                    leadRow.add((leadsRs.getString("personId")));
                    leadRow.add((leadsRs.getString("leadSource")));
                    leadRow.add((leadsRs.getString("conversionStatus")));
                    leadRow.add((leadsRs.getString("priorityScore")));
                    leadRow.add((leadsRs.getString("leadAcquisitionDate")));
                    leadRow.add((leadsRs.getString("targetConversionDate")));
                    leadRow.add((leadsRs.getString("p.company")));
                    
                }
                leadReport.add(leadRow);
                    
            }


            getLeads.close();
            conn.close();

            return leadReport;

        } catch (SQLException e) {
            System.out.println("Exception @getLeaddsReport");
            System.out.println(e);
        }
        return retrieveLeadsFromDB(statement);
    
    }
    public ArrayList<String> getReportColumnNames(ArrayList<Boolean> groupings){
        //p.company, leadSource, priorityScore, conversionStatus, acqmonth, targmonth
        ArrayList<String> colNames= new ArrayList<>();
        
        colNames.add("Average Priority Score");
        colNames.add("Overdue Leads");
        colNames.add("Conversion Success Rate");
        colNames.add("Total Leads");
        
        if (groupings.get(0))
            colNames.add("Company");
        if (groupings.get(1))
            colNames.add("Lead Source");
        if (groupings.get(2))
            colNames.add("Priority Score");
        if (groupings.get(3))
            colNames.add("Conversion Status");
        if (groupings.get(4))
            colNames.add("Month of Acquisition");
        if (groupings.get(5))
            colNames.add("Target Month of Conversion");
        
        if (colNames.size() == 4){
            colNames.clear();
            colNames.add("Lead Number");
            colNames.add("Person Id");
            colNames.add("Lead Source");
            colNames.add("Conversion Status");
            colNames.add("Priority Score");
            colNames.add("Month of Acquisition");
            colNames.add("Target Conversion Date");
            colNames.add("Company");
            //add more??
            
        
        }
        return colNames;
    }

    private ArrayList<ArrayList<String>> getBarChartData(String sql){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> data = new ArrayList<>();

        if(conn == null)
            return null;

        try{
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while(rs.next()){
                ArrayList<String> leadRow = new ArrayList<>();

                leadRow.add(rs.getString("barLength"));
                leadRow.add(rs.getString("category"));
                data.add(leadRow);   
            }

            stmt.close();
            conn.close();
            return data;
        } catch (SQLException e) {
            System.out.println("Exception @ getBarChartData");
            System.out.println(e.getMessage());
        }
        
        return null;
    }

    public ArrayList<ArrayList<String>> getLeadSourceInsight(){
        return getBarChartData(sqlLeadSourceInsight);
    }

    
    public ArrayList<ArrayList<String>> getConversionStatusInsight(){
        return getBarChartData(sqlConversionInsight);
    }

    public ArrayList<ArrayList<String>> getAcquisitionInsight(){
        return getBarChartData(sqlAcquisitionInsight);
    }
    

    public ArrayList<ArrayList<String>> sqlToGetGroupIndiv(String sql){
        Connection conn = connectToDB();
        PreparedStatement stmt;
        ResultSet rs;
        ArrayList<ArrayList<String>> indivLeads = new ArrayList<>(); 
                    ArrayList<String> a = new ArrayList<>();


        try{
            stmt = conn.prepareStatement(sql);
            // a.add(stmt.toString());
            rs = stmt.executeQuery();
            while(rs.next()){
                ArrayList<String> indiv = new ArrayList<>();
                indiv.add(rs.getString("name"));
                indiv.add(rs.getString("company"));
                indiv.add(rs.getString("leadSource"));
                indiv.add(rs.getString("conversionStatus"));
                indiv.add(rs.getString("priorityScore"));
                indiv.add(rs.getString("leadAcquisitionDate"));
                indiv.add(rs.getString("targetConversionDate"));

                indivLeads.add(indiv);
            }
            return indivLeads;
        } catch (SQLException e){
            a.add(e.getMessage());
            System.out.println("Exception @ getIndividualGroup");
            System.out.println(e.getMessage());
        }
        
        // indivLeads.add(a);
        return indivLeads;
        
    }
    

}
